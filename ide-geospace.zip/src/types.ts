export type GeometryType = "Point" | "LineString" | "Polygon" | "Collection" | "Mixed";

export interface LayerMetadata {
  count: number;
  projection: string;
  dateAdded: string;
  source: string;
  bbox?: [number, number, number, number]; // [minLon, minLat, maxLon, maxLat]
}

export interface GISLayer {
  id: string;
  name: string;
  type: GeometryType;
  geojson: any; // Full RFC 7946 FeatureCollection or Feature
  visible: boolean;
  opacity: number;
  color: string;      // Line/stroke color (hex)
  fillColor: string;  // Fill color (hex)
  weight: number;     // Stroke weight
  category: "ambient" | "socio" | "usuario" | "base";
  description: string;
  metadata: LayerMetadata;
  activeThematicField?: string; // Field chosen for thematic chloropleth/unique style rendering
}

export interface BaseMap {
  id: string;
  name: string;
  url: string;
  attribution: string;
  style: "light" | "dark" | "satellite" | "topo";
}

export interface SpatialMetric {
  totalFeatures: number;
  totalAreaSqKm?: number;
  totalLengthKm?: number;
  centroid?: [number, number]; // [lat, lng]
}

export interface Message {
  role: "user" | "model";
  text: string;
  timestamp: string;
}

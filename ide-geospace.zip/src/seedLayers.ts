import { GISLayer } from "./types";

// Seed layers with coordinate sets centered around Bolivia (Lat: -16.29, Lon: -63.59)
export const initialLayers: GISLayer[] = [
  {
    id: "sensor-network",
    name: "Red de Monitoreo Ambiental de Bolivia",
    type: "Point",
    visible: true,
    opacity: 0.9,
    color: "#e11d48", // rose-600
    fillColor: "#fb7185", // rose-400
    weight: 2,
    category: "ambient",
    description: "Estaciones meteorológicas y sensores de monitoreo de calidad del aire y radiación UV en ciudades principales y valles bolivianos.",
    metadata: {
      count: 5,
      projection: "EPSG:4326 (WGS 84)",
      dateAdded: "25/05/2026",
      source: "Servicio Nacional de Meteorología e Hidrología (SENAMHI)",
      bbox: [-69.0, -22.0, -57.0, -10.0]
    },
    geojson: {
      type: "FeatureCollection",
      features: [
        {
          type: "Feature",
          properties: {
            id: "SEN-LPZ",
            nombre: "Estación La Paz - Plaza Murillo",
            categoria: "Radiación UV",
            valor: 14, // Ultra-high UV index due to altitude
            descripcion: "Ubicada a 3650 msnm. Monitorea radiación solar extrema e índice UV.",
            temperatura_c: 12.8,
            humedad_pct: 35
          },
          geometry: {
            type: "Point",
            coordinates: [-68.1333, -16.4958]
          }
        },
        {
          type: "Feature",
          properties: {
            id: "SEN-SCZ",
            nombre: "Estación Santa Cruz - Equipetrol",
            categoria: "Humedad y Clima",
            valor: 5, // PM2.5 level (low, clean)
            descripcion: "Estación automatizada en el llano tropical boliviano.",
            temperatura_c: 28.5,
            humedad_pct: 78
          },
          geometry: {
            type: "Point",
            coordinates: [-63.1812, -17.7834]
          }
        },
        {
          type: "Feature",
          properties: {
            id: "SEN-CBB",
            nombre: "Estación Cochabamba - Kanata",
            categoria: "Calidad de Aire",
            valor: 52, // PM2.5 level (moderate/elevated due to valley inversion)
            descripcion: "Ubicada en el valle de Cochabamba. Registra inversión térmica.",
            temperatura_c: 22.1,
            humedad_pct: 45
          },
          geometry: {
            type: "Point",
            coordinates: [-66.1568, -17.3895]
          }
        },
        {
          type: "Feature",
          properties: {
            id: "SEN-UYU",
            nombre: "Estación Salar de Uyuni - Colchani",
            categoria: "Vientos y Clima",
            valor: 2, // PM2.5 level (pure air)
            descripcion: "Red de monitoreo de vientos del Altiplano meridional.",
            temperatura_c: 5.4,
            humedad_pct: 15
          },
          geometry: {
            type: "Point",
            coordinates: [-67.2435, -20.3005]
          }
        },
        {
          type: "Feature",
          properties: {
            id: "SEN-TJA",
            nombre: "Estación Tarija - Guadalquivir",
            categoria: "Humedad y Clima",
            valor: 4,
            descripcion: "Monitorea valles del sur y cuenca del río Guadalquivir.",
            temperatura_c: 19.2,
            humedad_pct: 55
          },
          geometry: {
            type: "Point",
            coordinates: [-64.7302, -21.5353]
          }
        }
      ]
    }
  },
  {
    id: "arterial-roads",
    name: "Red Vial Fundamental - Eje Troncal",
    type: "LineString",
    visible: true,
    opacity: 0.8,
    color: "#2563eb", // blue-600
    fillColor: "#3b82f6",
    weight: 4,
    category: "socio",
    description: "Carreteras principales que vinculan la zona andina, los valles centrales y las llanuras orientales de Bolivia.",
    metadata: {
      count: 3,
      projection: "EPSG:4326 (WGS 84)",
      dateAdded: "24/05/2026",
      source: "Administradora Boliviana de Carreteras (ABC)",
      bbox: [-69.0, -22.0, -57.0, -10.0]
    },
    geojson: {
      type: "FeatureCollection",
      features: [
        {
          type: "Feature",
          properties: {
            id: "RD-F1",
            nombre: "Autopista Corredor Andino (La Paz - Oruro)",
            categoria: "Integración Altiplano",
            valor: 4800, // Traffic volume (cars/day)
            descripcion: "Ruta Nacional 1. Conexión primordial del altiplano industrial.",
            longitud_m: 230000,
            velocidad_max: 110
          },
          geometry: {
            type: "LineString",
            coordinates: [
              [-68.1500, -16.5000],
              [-67.9500, -17.0000],
              [-67.5000, -17.5000],
              [-67.1100, -17.9600]
            ]
          }
        },
        {
          type: "Feature",
          properties: {
            id: "RD-F2",
            nombre: "Ruta de los Valles (Cochabamba - Santa Cruz)",
            categoria: "Vincular Oriente-Occidente",
            valor: 8200, // Traffic volume (cars/day)
            descripcion: "Ruta Nacional 4. Eje troncal de transporte agroindustrial e intermunicipal.",
            longitud_m: 480000,
            velocidad_max: 80
          },
          geometry: {
            type: "LineString",
            coordinates: [
              [-66.1568, -17.3895],
              [-65.5000, -17.4000],
              [-64.5000, -17.5000],
              [-63.8000, -17.6500],
              [-63.1812, -17.7834]
            ]
          }
        },
        {
          type: "Feature",
          properties: {
            id: "RD-F3",
            nombre: "Corredor Bioceánico (Santa Cruz - San José de Chiquitos)",
            categoria: "Exportación Chiquitanía",
            valor: 3100, // Traffic volume
            descripcion: "Carretera internacional que vincula el puerto fluvial de Puerto Suárez con el interior.",
            longitud_m: 280000,
            velocidad_max: 100
          },
          geometry: {
            type: "LineString",
            coordinates: [
              [-63.1812, -17.7834],
              [-62.5000, -17.8000],
              [-61.8000, -17.8500],
              [-60.7500, -17.8500]
            ]
          }
        }
      ]
    }
  },
  {
    id: "parks-and-forests",
    name: "Reservas Ecológicas y Parques Nacionales",
    type: "Polygon",
    visible: true,
    opacity: 0.65,
    color: "#059669", // emerald-600
    fillColor: "#10b981", // emerald-500
    weight: 2,
    category: "ambient",
    description: "Sistemas nacionales de áreas protegidas y ecoturismo de Bolivia, cubriendo hábitats megadiversos desde el Chaco hasta la Amazonía.",
    metadata: {
      count: 3,
      projection: "EPSG:4326 (WGS 84)",
      dateAdded: "23/05/2026",
      source: "Servicio Nacional de Áreas Protegidas (SERNAP)",
      bbox: [-69.0, -22.0, -57.0, -10.0]
    },
    geojson: {
      type: "FeatureCollection",
      features: [
        {
          type: "Feature",
          properties: {
            id: "RES-MAD",
            nombre: "Parque Nacional Madidi",
            categoria: "Amazónica Megadiversa",
            valor: 1895, // Area (thousands of hectares)
            descripcion: "Una de las reservas de biodiversidad más grandes del mundo, desde nieves eternas hasta selva tropical.",
            uso_publico: "Científico / Ecoturismo",
            arbolado_score: 98
          },
          geometry: {
            type: "Polygon",
            coordinates: [
              [
                [-68.8000, -14.2000],
                [-68.0000, -14.2000],
                [-68.0000, -14.8000],
                [-68.8000, -14.8000],
                [-68.8000, -14.2000] // Loop closed
              ]
            ]
          }
        },
        {
          type: "Feature",
          properties: {
            id: "RES-NKP",
            nombre: "Parque Nacional Noel Kempff Mercado",
            categoria: "Patrimonio de la Humanidad",
            valor: 1523, // Area (thousands of hectares)
            descripcion: "Ubicado en la meseta de Caparuch, cuenta con caídas de agua hermosas y hábitats vírgenes del precámbrico.",
            uso_publico: "Científico / Conservación",
            arbolado_score: 94
          },
          geometry: {
            type: "Polygon",
            coordinates: [
              [
                [-61.5000, -14.0000],
                [-60.5000, -14.0000],
                [-60.5000, -15.0000],
                [-61.5000, -15.0000],
                [-61.5000, -14.0000] // Loop closed
              ]
            ]
          }
        },
        {
          type: "Feature",
          properties: {
            id: "RES-UYU",
            nombre: "Amortiguamiento Salar Grande de Uyuni",
            categoria: "Reserva Geológica",
            valor: 1058, // Area (thousands of hectares)
            descripcion: "El desierto de sal continuo más grande del planeta. Conforma una cuenca endorreica altoandina extrema.",
            uso_publico: "Turismo Masivo Regulado",
            arbolado_score: 2
          },
          geometry: {
            type: "Polygon",
            coordinates: [
              [
                [-67.8000, -20.0000],
                [-66.8000, -20.0000],
                [-66.8000, -20.8000],
                [-67.8000, -20.8000],
                [-67.8000, -20.0000] // Loop closed
              ]
            ]
          }
        }
      ]
    }
  }
];

import { useState } from "react";
import { initialLayers } from "./seedLayers";
import { GISLayer } from "./types";
import MapViewer from "./components/MapViewer";
import LayerCatalog from "./components/LayerCatalog";
import SpatialAnalysis from "./components/SpatialAnalysis";
import AttributeTable from "./components/AttributeTable";
import AISpatialConsultant from "./components/AISpatialConsultant";
import OGCPortal from "./components/OGCPortal";
import {
  Layers,
  Compass,
  Globe,
  Brain,
  MessageSquare,
  ChevronDown,
  ChevronUp,
  MapPin,
  Table,
  HelpCircle,
  Sparkles,
  Info
} from "lucide-react";

export default function App() {
  const [layers, setLayers] = useState<GISLayer[]>(initialLayers);
  const [selectedLayerId, setSelectedLayerId] = useState<string | null>("sensor-network");
  const [activeTab, setActiveTab] = useState<"catalog" | "analysis" | "ogc">("catalog");
  const [showTablePanel, setShowTablePanel] = useState(true);
  const [showAIConsultant, setShowAIConsultant] = useState(true);

  // Map state configurations
  const [centerCoordinates, setCenterCoordinates] = useState<[number, number]>([-16.290154, -63.588653]); // Centered on Bolivia
  const [zoomLevel, setZoomLevel] = useState<number>(6);
  const [drawMode, setDrawMode] = useState<"none" | "point" | "polygon">("none");

  // Select layer handler
  const handleSelectLayer = (id: string) => {
    setSelectedLayerId(id);
  };

  // Toggle visibility checkbox
  const handleToggleVisibility = (id: string) => {
    setLayers((prev) =>
      prev.map((l) => (l.id === id ? { ...l, visible: !l.visible } : l))
    );
  };

  // Slider change opacity
  const handleUpdateOpacity = (id: string, opacity: number) => {
    setLayers((prev) =>
      prev.map((l) => (l.id === id ? { ...l, opacity } : l))
    );
  };

  // Modify Layer colours and thickness styles
  const handleUpdateStyle = (id: string, color: string, fillColor: string, weight: number) => {
    setLayers((prev) =>
      prev.map((l) =>
        l.id === id ? { ...l, color, fillColor, weight } : l
      )
    );
  };

  // AI design style helper applied to active selected layer
  const handleApplyStyleSuggestion = (layerId: string, style: { fillColor?: string, color?: string, weight?: number, opacity?: number }) => {
    setLayers((prev) =>
      prev.map((l) =>
        l.id === layerId
          ? {
              ...l,
              fillColor: style.fillColor || l.fillColor,
              color: style.color || l.color,
              weight: style.weight || l.weight,
              opacity: style.opacity !== undefined ? style.opacity : l.opacity
            }
          : l
      )
    );
  };

  // Apply chloropleth classification on field value
  const handleApplyThematicClassification = (layerId: string, fieldName: string | null) => {
    setLayers((prev) =>
      prev.map((l) =>
        l.id === layerId ? { ...l, activeThematicField: fieldName } : l
      )
    );
  };

  // Add new layer (e.g. from File uploaded or AI synthesized)
  const handleAddLayer = (newLayer: GISLayer) => {
    setLayers((prev) => [newLayer, ...prev]);
    setSelectedLayerId(newLayer.id);

    // Zoom and pan to coordinates if loaded features are point arrays
    try {
      if (newLayer.geojson?.features?.length > 0) {
        const firstFeature = newLayer.geojson.features[0];
        if (firstFeature?.geometry?.type === "Point") {
          const [lon, lat] = firstFeature.geometry.coordinates;
          setCenterCoordinates([lat, lon]);
          setZoomLevel(12);
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Delete layer Action
  const handleRemoveLayer = (id: string) => {
    setLayers((prev) => prev.filter((l) => l.id !== id));
    if (selectedLayerId === id) {
      setSelectedLayerId(layers.length > 1 ? layers[0].id : null);
    }
  };

  // Digitalization click handler inside MapViewer completed
  const handleDrawingComplete = (geojsonFeature: any) => {
    const activeSelected = layers.find((l) => l.id === selectedLayerId);

    if (activeSelected && (activeSelected.id.startsWith("usr-") || activeSelected.id === "sensor-network")) {
      // Append feature directly to currently selected user layers
      const updatedGeoJSON = {
        ...activeSelected.geojson,
        features: [...activeSelected.geojson.features, geojsonFeature]
      };

      setLayers((prev) =>
        prev.map((l) =>
          l.id === activeSelected.id
            ? {
                ...l,
                geojson: updatedGeoJSON,
                metadata: {
                  ...l.metadata,
                  count: updatedGeoJSON.features.length
                }
              }
            : l
        )
      );
    } else {
      // Create a brand new vector layer containing the user drawn element
      const drawLayerId = `usr-draw-${Date.now()}`;
      const newDrawnLayer: GISLayer = {
        id: drawLayerId,
        name: geojsonFeature.properties.nombre || "Digitalización Manual",
        type: geojsonFeature.geometry.type,
        visible: true,
        opacity: 0.85,
        color: "#f59e0b", // amber-500
        fillColor: "#fef3c7", // amber-100
        weight: 3,
        category: "usuario",
        description: "Capa autogenerada y capturada interactivamente mediante los lápices de digitalización del visualizador.",
        metadata: {
          count: 1,
          projection: "WGS 84 (EPSG:4326)",
          dateAdded: new Date().toLocaleDateString(),
          source: "Digitalizador Manual Activo",
        },
        geojson: {
          type: "FeatureCollection",
          features: [geojsonFeature]
        }
      };

      setLayers((prev) => [newDrawnLayer, ...prev]);
      setSelectedLayerId(drawLayerId);
    }
  };

  // Inspect feature tabular select callback
  const handleFeatureSelect = (properties: any, geometry: any) => {
    console.log("Feature selected on map:", properties, geometry);
  };

  // Spreadsheet row click highlight zoom mapping
  const handleFeatureHighlight = (coordinates: [number, number], properties: any) => {
    setCenterCoordinates(coordinates);
    setZoomLevel(14);
  };

  const currentSelectedLayer = layers.find((l) => l.id === selectedLayerId) || null;

  return (
    <div className="flex flex-col h-screen w-full bg-sdi-slate-bg text-slate-100 font-sans overflow-hidden select-none">
      {/* Prime Header navigation bar */}
      <header className="bg-sdi-slate-card border-b border-sdi-slate-border p-4.5 flex items-center justify-between shrink-0 h-[64px] shadow-lg">
        <div className="flex items-center space-x-3 text-left">
          <div className="bg-sdi-slate-bg border border-sdi-slate-border p-2 rounded-xl text-sdi-blue shadow-md flex items-center justify-center">
            <Globe className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-bold text-[14px] uppercase tracking-wider text-sdi-blue leading-tight">
              GEO-CORE <span className="text-slate-50">SDI</span>
            </h1>
            <p className="text-[10px] text-sdi-slate-mute font-medium tracking-wide">Infraestructura de Datos Espaciales Inteligente</p>
          </div>
        </div>

        {/* Global Tab Controller */}
        <div className="flex items-center space-x-1.5 bg-sdi-slate-darker p-1 rounded-xl border border-sdi-slate-border">
          <button
            onClick={() => setActiveTab("catalog")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition cursor-pointer ${
              activeTab === "catalog"
                ? "bg-sdi-blue text-sdi-slate-darker shadow-sm font-bold"
                : "text-sdi-slate-mute hover:text-slate-200"
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Capas e Importación</span>
          </button>
          <button
            onClick={() => setActiveTab("analysis")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition cursor-pointer ${
              activeTab === "analysis"
                ? "bg-sdi-blue text-sdi-slate-darker shadow-sm font-bold"
                : "text-sdi-slate-mute hover:text-slate-200"
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Geoprocesamiento</span>
          </button>
          <button
            onClick={() => setActiveTab("ogc")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition cursor-pointer ${
              activeTab === "ogc"
                ? "bg-sdi-blue text-sdi-slate-darker shadow-sm font-bold"
                : "text-sdi-slate-mute hover:text-slate-200"
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Servicios OGC</span>
          </button>
        </div>

        {/* Sidebar panels toggles */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowAIConsultant(!showAIConsultant)}
            className={`p-2 rounded-xl transition cursor-pointer border ${
              showAIConsultant
                ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400"
                : "bg-sdi-slate-bg border-sdi-slate-border text-sdi-slate-mute hover:text-slate-200"
            }`}
            title="Consola de Consultoría de IA"
          >
            <Brain className="w-4.5 h-4.5" />
          </button>
          <button
            onClick={() => setShowTablePanel(!showTablePanel)}
            className={`p-2 rounded-xl transition cursor-pointer border ${
              showTablePanel
                ? "bg-sdi-blue/10 border-sdi-blue/30 text-sdi-blue"
                : "bg-sdi-slate-bg border-sdi-slate-border text-sdi-slate-mute hover:text-slate-200"
            }`}
            title="Tabla de Atributos"
          >
            <Table className="w-4.5 h-4.5" />
          </button>
        </div>
      </header>

      {/* Main split viewport layout */}
      <main className="flex-1 flex overflow-hidden relative bg-sdi-slate-bg">
        {/* Left Side: Map display and Table Inspector */}
        <div className="flex-1 flex flex-col p-4 space-y-4 overflow-hidden bg-sdi-slate-bg">
          {/* Map display */}
          <div className="flex-1 min-h-[220px]">
            <MapViewer
              layers={layers}
              selectedLayerId={selectedLayerId}
              onFeatureSelect={handleFeatureSelect}
              drawMode={drawMode}
              setDrawMode={setDrawMode}
              onDrawingComplete={handleDrawingComplete}
              centerCoordinates={centerCoordinates}
              zoomLevel={zoomLevel}
            />
          </div>

          {/* Bottom table panel */}
          {showTablePanel && (
            <div className="h-[28%] min-h-[160px] shrink-0 transform transition-all duration-350">
              <AttributeTable
                layers={layers}
                selectedLayerId={selectedLayerId}
                onFeatureHighlight={handleFeatureHighlight}
              />
            </div>
          )}
        </div>

        {/* Middle/Right Swappable Sidebar Tab context Panel */}
        <div className="w-[320px] shrink-0 border-l border-sdi-slate-border p-4 pl-0 overflow-y-auto flex flex-col h-full space-y-4 bg-sdi-slate-bg">
          <div className="flex-1">
            {activeTab === "catalog" && (
              <LayerCatalog
                layers={layers}
                selectedLayerId={selectedLayerId}
                onSelectLayer={handleSelectLayer}
                onToggleVisibility={handleToggleVisibility}
                onUpdateOpacity={handleUpdateOpacity}
                onUpdateStyle={handleUpdateStyle}
                onAddLayer={handleAddLayer}
                onRemoveLayer={handleRemoveLayer}
                onApplyThematicClassification={handleApplyThematicClassification}
              />
            )}
            {activeTab === "analysis" && (
              <SpatialAnalysis
                layers={layers}
                selectedLayerId={selectedLayerId}
                onAddLayer={handleAddLayer}
                drawMode={drawMode}
                setDrawMode={setDrawMode}
              />
            )}
            {activeTab === "ogc" && <OGCPortal />}
          </div>

          {/* Collapsed floating IA Assistant if visible */}
          {showAIConsultant && (
            <div className="h-[42%] min-h-[220px] shrink-0 pt-2 border-t border-sdi-slate-border/80">
              <AISpatialConsultant
                activeLayer={currentSelectedLayer}
                onApplyStyleSuggestion={handleApplyStyleSuggestion}
              />
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

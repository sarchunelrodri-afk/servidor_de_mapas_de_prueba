import React, { useState, useRef } from "react";
import { GISLayer, GeometryType } from "../types";
import {
  Layers,
  UploadCloud,
  Eye,
  EyeOff,
  Sparkles,
  Trash2,
  Sliders,
  Download,
  CheckCircle,
  Brain,
  Tag,
  Palette
} from "lucide-react";

interface LayerCatalogProps {
  layers: GISLayer[];
  selectedLayerId: string | null;
  onSelectLayer: (id: string) => void;
  onToggleVisibility: (id: string) => void;
  onUpdateOpacity: (id: string, opacity: number) => void;
  onUpdateStyle: (id: string, color: string, fillColor: string, weight: number) => void;
  onAddLayer: (layer: GISLayer) => void;
  onRemoveLayer: (id: string) => void;
  onApplyThematicClassification: (id: string, fieldName: string | null) => void;
}

export default function LayerCatalog({
  layers,
  selectedLayerId,
  onSelectLayer,
  onToggleVisibility,
  onUpdateOpacity,
  onUpdateStyle,
  onAddLayer,
  onRemoveLayer,
  onApplyThematicClassification
}: LayerCatalogProps) {
  const [dragActive, setDragActive] = useState(false);
  const [aiPrompt, setAiPrompt] = useState("");
  const [loadingAi, setLoadingAi] = useState(false);
  const [expandedStyles, setExpandedStyles] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // File parsing (GeoJSON & CSV)
  const processUploadedFile = (file: File) => {
    const reader = new FileReader();

    if (file.name.endsWith(".json") || file.name.endsWith(".geojson")) {
      reader.onload = (e) => {
        try {
          const content = JSON.parse(e.target?.result as string);
          if (!content.type || !content.features) {
            alert("El archivo JSON no parece ser un formato GeoJSON estandar (debe incluir 'type': 'FeatureCollection' o similar).");
            return;
          }

          // Deduce main geometry type of the collection
          let detectedType: GeometryType = "Mixed";
          if (content.features.length > 0) {
            const firstGeom = content.features[0].geometry?.type;
            if (firstGeom === "Point") detectedType = "Point";
            else if (firstGeom === "LineString") detectedType = "LineString";
            else if (firstGeom === "Polygon") detectedType = "Polygon";
          }

          const newLayer: GISLayer = {
            id: `usr-lyr-${Date.now()}`,
            name: file.name.replace(/\.[^/.]+$/, ""), // remove extension
            type: detectedType,
            geojson: content,
            visible: true,
            opacity: 0.8,
            color: "#6366f1", // purple-500
            fillColor: "#a5b4fc", // purple-300
            weight: 3,
            category: "usuario",
            description: `Capa importada desde archivo local. Contiene ${content.features.length} geometrías registradas.`,
            metadata: {
              count: content.features.length,
              projection: "WGS 84 (EPSG:4326)",
              dateAdded: new Date().toLocaleDateString(),
              source: "Archivo cargado por usuario",
            }
          };

          onAddLayer(newLayer);
        } catch (err) {
          alert("Error al parsear el archivo GeoJSON. Verifique la sintaxis estructural.");
        }
      };
      reader.readAsText(file);
    } else {
      alert("Por favor cargue un archivo con extensión .geojson o .json.");
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processUploadedFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processUploadedFile(e.target.files[0]);
    }
  };

  // Generate mock or real layer coordinates using Gemini
  const handleAiLayerGeneration = async () => {
    if (!aiPrompt.trim()) return;
    setLoadingAi(true);

    try {
      const res = await fetch("/api/gemini/generate-layer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ theme: aiPrompt }),
      });

      const data = await res.json();
      if (data.success && data.geojson) {
        // Find geometry type
        let gType: GeometryType = "Point";
        if (data.geojson.features && data.geojson.features.length > 0) {
          const typeCandidate = data.geojson.features[0].geometry?.type;
          if (typeCandidate === "Polygon") gType = "Polygon";
          else if (typeCandidate === "LineString") gType = "LineString";
        }

        const aiGeneratedLayer: GISLayer = {
          id: `ai-lyr-${Date.now()}`,
          name: data.geojson.name || `Capa IA: ${aiPrompt.slice(0, 24)}...`,
          type: gType,
          geojson: data.geojson,
          visible: true,
          opacity: 0.85,
          color: gType === "Polygon" ? "#0284c7" : gType === "LineString" ? "#ea580c" : "#16a34a",
          fillColor: gType === "Polygon" ? "#7dd3fc" : gType === "LineString" ? "#fdba74" : "#86efac",
          weight: 3,
          category: "usuario",
          description: `Cartografía sintetizada automáticamente por Inteligencia Artificial (Gemini) sobre el tema "${aiPrompt}".`,
          metadata: {
            count: data.geojson.features?.length || 0,
            projection: "WGS 84 (EPSG:4326)",
            dateAdded: new Date().toLocaleDateString(),
            source: "Sintetizador Geoespacial Gemini-3.5",
          }
        };

        onAddLayer(aiGeneratedLayer);
        setAiPrompt("");
      } else {
        alert(data.message || "No se pudo generar la capa. Compruebe la conexión o secretos.");
      }
    } catch (e: any) {
      console.error(e);
      alert("Error estableciendo contacto con el servidor de IA.");
    } finally {
      setLoadingAi(false);
    }
  };

  // Download layer as JSON / GeoJSON
  const handleDownloadLayer = (layer: GISLayer) => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(layer.geojson));
    const dlAnchorElem = document.createElement("a");
    dlAnchorElem.setAttribute("href", dataStr);
    dlAnchorElem.setAttribute("download", `${layer.name.toLowerCase().replace(/\s+/g, "_")}.geojson`);
    dlAnchorElem.click();
  };

  const getCategoryTitle = (cat: string) => {
    switch (cat) {
      case "ambient": return "Capas Ambientales / Ecológicas";
      case "socio": return "Capas Socioeconómicas / Vías";
      case "usuario": return "Copias de Entrada / Dibujos / IA";
      default: return "Otras Capas";
    }
  };

  // Deduce numerical fields for potential styling filters
  const getNumericalFields = (layer: GISLayer): string[] => {
    const fields = new Set<string>();
    try {
      if (layer.geojson?.features) {
        layer.geojson.features.forEach((feat: any) => {
          if (feat.properties) {
            Object.keys(feat.properties).forEach((key) => {
              if (typeof feat.properties[key] === "number") {
                fields.add(key);
              }
            });
          }
        });
      }
    } catch (e) {
      console.error(e);
    }
    return Array.from(fields);
  };

  return (
    <div className="flex flex-col h-full bg-sdi-slate-card border border-sdi-slate-border rounded-xl overflow-hidden shadow-xl text-slate-100">
      {/* Catalog Header */}
      <div className="bg-sdi-slate-darker p-4 border-b border-sdi-slate-border flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Layers className="w-5 h-5 text-sdi-blue" />
          <h2 className="font-semibold text-sm uppercase tracking-wider text-slate-100">Catálogo de Capas IDE</h2>
        </div>
        <span className="bg-sdi-slate-bg border border-sdi-slate-border px-2.5 py-1 rounded-full text-[10px] font-bold text-sdi-blue">
          {layers.length} Activas
        </span>
      </div>

      {/* Accordion / Catalog Content & Drag Drop */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Dynamic Drag and drop loader */}
        <div
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all ${
            dragActive
              ? "border-sdi-blue bg-sdi-blue/10 text-sdi-blue"
              : "border-sdi-slate-border hover:border-sdi-blue hover:bg-sdi-slate-bg/30 text-sdi-slate-mute"
          }`}
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileInputChange}
            accept=".geojson,.json"
            className="hidden"
          />
          <UploadCloud className="w-8 h-8 mx-auto mb-2 text-slate-500 group-hover:text-slate-300" />
          <p className="text-xs font-semibold text-slate-300">Cargar Archivo de Cartografía (.geojson)</p>
          <p className="text-[10px] text-slate-500 mt-1">Suelte el archivo aquí o haga click para buscar</p>
        </div>

        {/* Categories rendering */}
        {["usuario", "ambient", "socio"].map((category) => {
          const categoryLayers = layers.filter((l) => l.category === category);
          if (categoryLayers.length === 0) return null;

          return (
            <div key={category} className="space-y-2">
              <h3 className="text-[10px] font-bold uppercase text-sdi-slate-mute tracking-wider">
                {getCategoryTitle(category)}
              </h3>
              <div className="space-y-2">
                {categoryLayers.map((layer) => {
                  const isSelected = selectedLayerId === layer.id;
                  const numericalFields = getNumericalFields(layer);

                  return (
                    <div
                      key={layer.id}
                      onClick={() => onSelectLayer(layer.id)}
                      className={`group p-3 rounded-xl border transition-all ${
                        isSelected
                          ? "bg-sdi-slate-darker border-sdi-blue shadow-sm"
                          : "bg-sdi-slate-bg/40 border-sdi-slate-border hover:bg-sdi-slate-bg/80"
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-2.5 min-w-0">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onToggleVisibility(layer.id);
                            }}
                            className={`p-1 rounded hover:bg-sdi-slate-hover/30 transition-colors ${
                              layer.visible ? "text-sdi-blue" : "text-sdi-slate-mute"
                            }`}
                          >
                            {layer.visible ? (
                              <Eye className="w-4 h-4" />
                            ) : (
                              <EyeOff className="w-4 h-4" />
                            )}
                          </button>
                          <div className="min-w-0">
                            <h4 className="text-xs font-semibold text-slate-100 truncate">
                              {layer.name}
                            </h4>
                            <p className="text-[10px] text-sdi-slate-mute font-mono capitalize">
                              {layer.type} • {layer.metadata.count} features
                            </p>
                          </div>
                        </div>

                        {/* Quick controls icons */}
                        <div className="flex items-center space-x-1 shrink-0 opacity-80 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setExpandedStyles(expandedStyles === layer.id ? null : layer.id);
                            }}
                            title="Ajustar Estilo"
                            className="p-1 rounded text-sdi-slate-mute hover:text-sdi-blue hover:bg-sdi-slate-hover/30"
                          >
                            <Sliders className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDownloadLayer(layer);
                            }}
                            title="Exportar GeoJSON"
                            className="p-1 rounded text-sdi-slate-mute hover:text-emerald-400 hover:bg-sdi-slate-hover/30"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>
                          {layer.id.startsWith("usr-") || layer.id.startsWith("ai-") ? (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onRemoveLayer(layer.id);
                              }}
                              title="Remover Capa"
                              className="p-1 rounded text-sdi-slate-mute hover:text-rose-500 hover:bg-sdi-slate-hover/30"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          ) : null}
                        </div>
                      </div>

                      {/* Expandable Styles HUD Panel */}
                      {expandedStyles === layer.id && (
                        <div
                          className="mt-3 bg-sdi-slate-bg p-2.5 rounded border border-sdi-slate-border space-y-3 font-mono text-[11px]"
                          onClick={(e) => e.stopPropagation()}
                        >
                          {/* Opacity slider */}
                          <div>
                            <div className="flex justify-between text-sdi-slate-mute mb-1">
                              <span>Opacidad:</span>
                              <span>{Math.round(layer.opacity * 100)}%</span>
                            </div>
                            <input
                              type="range"
                              min="0"
                              max="1"
                              step="0.1"
                              value={layer.opacity}
                              onChange={(e) => onUpdateOpacity(layer.id, parseFloat(e.target.value))}
                              className="w-full accent-sdi-blue cursor-pointer text-slate-600 bg-sdi-slate-darker"
                            />
                          </div>

                          {/* Quick Colors Selector */}
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <span className="text-sdi-slate-mute block mb-1">Línea:</span>
                              <div className="flex space-x-1.5">
                                {["#ef4444", "#3b82f6", "#10b981", "#ca8a04", "#8b5cf6", "#f43f5e"].map((c) => (
                                  <button
                                    key={c}
                                    onClick={() => onUpdateStyle(layer.id, c, layer.fillColor, layer.weight)}
                                    style={{ backgroundColor: c }}
                                    className={`w-4 h-4 rounded-full border border-slate-100 ${
                                      layer.color === c ? "ring-2 ring-sdi-blue ring-offset-1 ring-offset-sdi-slate-bg" : ""
                                    }`}
                                  />
                                ))}
                              </div>
                            </div>
                            <div>
                              <span className="text-sdi-slate-mute block mb-1">Fondo:</span>
                              <div className="flex space-x-1.5">
                                {["#fca5a5", "#93c5fd", "#6ee7b7", "#fef08a", "#c4b5fd", "#fda4af"].map((fc) => (
                                  <button
                                    key={fc}
                                    onClick={() => onUpdateStyle(layer.id, layer.color, fc, layer.weight)}
                                    style={{ backgroundColor: fc }}
                                    className={`w-4 h-4 rounded-full border border-slate-100 ${
                                      layer.fillColor === fc ? "ring-2 ring-sdi-blue ring-offset-1 ring-offset-sdi-slate-bg" : ""
                                    }`}
                                  />
                                ))}
                              </div>
                            </div>
                          </div>

                          {/* Thematic Choropleth Classification */}
                          {numericalFields.length > 0 && (
                            <div className="border-t border-sdi-slate-border/80 pt-2.5">
                              <span className="text-sdi-slate-mute flex items-center mb-1">
                                <Palette className="w-3 h-3 text-sdi-blue mr-1" />
                                Clasificación Temática:
                              </span>
                              <select
                                value={layer.activeThematicField || ""}
                                onChange={(e) =>
                                  onApplyThematicClassification(layer.id, e.target.value || null)
                                }
                                className="w-full bg-sdi-slate-darker border border-sdi-slate-border rounded p-1 text-slate-200"
                              >
                                <option value="">Sin temática (Estilo Único)</option>
                                {numericalFields.map((field) => (
                                  <option key={field} value={field}>
                                    Gradiente por campo: {field}
                                  </option>
                                ))}
                              </select>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Dynamic AI Layer Generator Box */}
      <div className="bg-sdi-slate-card p-4 border-t border-sdi-slate-border">
        <div className="flex items-center space-x-1.5 mb-2">
          <Brain className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-bold uppercase tracking-wider text-sdi-slate-mute">Generar Cartografía con IA</span>
        </div>
        <div className="flex items-center space-x-2">
          <input
            type="text"
            value={aiPrompt}
            onChange={(e) => setAiPrompt(e.target.value)}
            placeholder="ej. 'Poblaciones indigenas en Colombia'"
            className="flex-1 bg-sdi-slate-bg border border-sdi-slate-border px-3 py-2 rounded-lg text-xs text-slate-100 placeholder-sdi-slate-mute focus:outline-none focus:border-sdi-blue font-medium"
            disabled={loadingAi}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleAiLayerGeneration();
            }}
          />
          <button
            onClick={handleAiLayerGeneration}
            disabled={loadingAi || !aiPrompt.trim()}
            className="bg-emerald-600 hover:bg-emerald-700 disabled:bg-sdi-slate-bg border border-sdi-slate-border/20 text-slate-105 p-2.5 rounded-lg transition duration-150 relative cursor-pointer"
            title="Sintetizar Capa Inteligente"
          >
            {loadingAi ? (
              <div className="w-4.5 h-4.5 border-2 border-slate-300 border-t-emerald-600 rounded-full animate-spin" />
            ) : (
              <Sparkles className="w-4.5 h-4.5" />
            )}
          </button>
        </div>
        <p className="text-[10px] text-slate-500 mt-1.5 leading-relaxed text-left">
          Gemini formulará un set de features GeoJSON reales con coordenadas lógicas según el tema espacial solicitado.
        </p>
      </div>
    </div>
  );
}

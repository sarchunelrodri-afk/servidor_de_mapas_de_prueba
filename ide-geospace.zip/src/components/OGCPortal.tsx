import React, { useState } from "react";
import { Copy, Check, ExternalLink, Globe, Database, Network } from "lucide-react";

export default function OGCPortal() {
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);

  const triggerCopyFeed = (url: string, id: string) => {
    navigator.clipboard.writeText(url);
    setCopiedUrl(id);
    setTimeout(() => setCopiedUrl(null), 1800);
  };

  const getFullUrl = (relativePath: string) => {
    return `${window.location.origin}${relativePath}`;
  };

  return (
    <div className="flex flex-col h-full bg-sdi-slate-card border border-sdi-slate-border rounded-xl overflow-hidden shadow-xl text-slate-100 font-sans">
      {/* Title Header */}
      <div className="bg-sdi-slate-darker p-4 border-b border-sdi-slate-border flex items-center space-x-2 text-left">
        <Globe className="w-5 h-5 text-sdi-blue" />
        <div>
          <h2 className="font-bold text-sm uppercase tracking-wider text-slate-100">Portal de Servicios OGC / IDE</h2>
          <p className="text-[10px] text-sdi-slate-mute">Interoperabilidad territorial para SIG (QGIS, ArcGIS)</p>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-5 text-left">
        <div className="bg-sdi-slate-bg p-3.5 rounded-xl border border-sdi-slate-border">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5 border-b border-sdi-slate-border/50 pb-2 mb-2">
            <Network className="w-4 h-4 text-emerald-400" />
            ¿Qué es este Nodo de IDE?
          </h3>
          <p className="text-[11px] text-sdi-slate-mute leading-relaxed">
            Una <strong>Infraestructura de Datos Espaciales (IDE)</strong> es una plataforma diseñada para alojar, publicar e intercambiar información geográfica estandarizada mediante servicios web estandarizados (consorcio OGC), garantizando que cualquier usuario pueda consumir estas capas directamente en computadores locales o sistemas remotos.
          </p>
        </div>

        {/* Services List cards */}
        <div className="space-y-4">
          <div className="bg-sdi-slate-darker/60 p-3.5 rounded-xl border border-sdi-slate-border space-y-3">
            <div className="flex items-center justify-between">
              <span className="bg-sdi-blue/10 border border-sdi-blue/20 text-sdi-blue px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider">
                WMS (Web Map Service)
              </span>
              <span className="text-[10px] font-mono text-sdi-slate-mute">v1.3.0 Standard</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              Distribuye teselas de mapas rasterizadas renderizadas dinámicamente por nuestro servidor cartográfico. Ideal para fondos visuales ligeros en software GIS externo.
            </p>
            <div className="space-y-1.5 font-mono text-[10px]">
              <span className="text-sdi-slate-mute block">Enlace de GetCapabilities:</span>
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  readOnly
                  value={getFullUrl("/api/ogc/wms?service=WMS&request=GetCapabilities")}
                  className="flex-1 bg-sdi-slate-bg border border-sdi-slate-border px-2.5 py-1.5 rounded-lg text-slate-200 select-all font-mono outline-none"
                />
                <button
                  onClick={() => triggerCopyFeed(getFullUrl("/api/ogc/wms?service=WMS&request=GetCapabilities"), "wms")}
                  className="bg-sdi-slate-bg hover:bg-sdi-slate-hover px-2.5 py-1.5 rounded-lg border border-sdi-slate-border text-sdi-blue transition cursor-pointer"
                >
                  {copiedUrl === "wms" ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>

          <div className="bg-sdi-slate-darker/60 p-3.5 rounded-xl border border-sdi-slate-border space-y-3">
            <div className="flex items-center justify-between">
              <span className="bg-purple-500/10 border border-purple-500/30 text-purple-400 px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider">
                WFS (Web Feature Service)
              </span>
              <span className="text-[10px] font-mono text-sdi-slate-mute">v2.0.0 Standard</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              Expone directamente el set de datos en formato vectorial (coordenadas brutas y tabla alfanumérica) para permitir geoprocesamiento nativo y manipulación de datos espaciales.
            </p>
            <div className="space-y-1.5 font-mono text-[10px]">
              <span className="text-sdi-slate-mute block">Enlace de GetCapabilities:</span>
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  readOnly
                  value={getFullUrl("/api/ogc/wfs?service=WFS&request=GetCapabilities")}
                  className="flex-1 bg-sdi-slate-bg border border-sdi-slate-border px-2.5 py-1.5 rounded-lg text-slate-200 select-all font-mono outline-none"
                />
                <button
                  onClick={() => triggerCopyFeed(getFullUrl("/api/ogc/wfs?service=WFS&request=GetCapabilities"), "wfs")}
                  className="bg-sdi-slate-bg hover:bg-sdi-slate-hover px-2.5 py-1.5 rounded-lg border border-sdi-slate-border text-sdi-blue transition cursor-pointer"
                >
                  {copiedUrl === "wfs" ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Integration Instructions */}
        <div className="bg-sdi-slate-bg p-3.5 rounded-xl border border-sdi-slate-border space-y-2">
          <h4 className="text-[11px] font-bold text-slate-300 uppercase tracking-widest flex items-center gap-1.5">
            <Database className="w-3.5 h-3.5 text-sdi-blue" />
            ¿Cómo consumirlos en QGIS?
          </h4>
          <ol className="text-[10px] text-sdi-slate-mute list-decimal pl-4 space-y-1">
            <li>Abra su cliente local <strong>QGIS Desktop</strong>.</li>
            <li>En el navegador, clic secundario sobre <strong>"WMS/WMTS"</strong> (o WFS).</li>
            <li>Seleccione <strong>"Nueva Conexión"</strong>.</li>
            <li>Pegue el link de Capabilities que copió arriba en el campo URL y haga clic en OK.</li>
            <li>Haga doble clic sobre la capa que se añade para incorporarla al lienzo del mapa.</li>
          </ol>
        </div>
      </div>
    </div>
  );
}

import React, { useState, useMemo } from "react";
import { GISLayer } from "../types";
import { Table, Search, ArrowUpDown, Download, MapPin, Eye } from "lucide-react";

interface AttributeTableProps {
  layers: GISLayer[];
  selectedLayerId: string | null;
  onFeatureHighlight: (coordinates: [number, number], properties: any) => void;
}

export default function AttributeTable({
  layers,
  selectedLayerId,
  onFeatureHighlight
}: AttributeTableProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortField, setSortField] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");

  // Retrieve active layer
  const activeLayer = useMemo(() => {
    return layers.find((l) => l.id === selectedLayerId);
  }, [layers, selectedLayerId]);

  // Extract all unique property keys (columns) across all features
  const tableHeaders = useMemo(() => {
    if (!activeLayer?.geojson?.features) return [];
    const keys = new Set<string>();
    activeLayer.geojson.features.forEach((feature: any) => {
      if (feature.properties) {
        Object.keys(feature.properties).forEach((key) => {
          // Exclude bulky sub-objects/nested keys for simple tabular representation
          if (typeof feature.properties[key] !== "object") {
            keys.add(key);
          }
        });
      }
    });
    // Ensure 'id' or 'nombre' comes first
    const list = Array.from(keys);
    const sortedList: string[] = [];
    if (list.includes("nombre")) sortedList.push("nombre");
    else if (list.includes("name")) sortedList.push("name");
    if (list.includes("id")) sortedList.push("id");

    list.forEach((key) => {
      if (key !== "nombre" && key !== "name" && key !== "id") {
        sortedList.push(key);
      }
    });

    return sortedList;
  }, [activeLayer]);

  // Extract tabular rows
  const tableRows = useMemo(() => {
    if (!activeLayer?.geojson?.features) return [];
    return activeLayer.geojson.features.map((feature: any, index: number) => ({
      properties: feature.properties || {},
      geometry: feature.geometry,
      index
    }));
  }, [activeLayer]);

  // Handle column sorting toggle
  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  // Filter and Sort rows
  const processedRows = useMemo(() => {
    let rows = [...tableRows];

    // Search filter
    if (searchTerm.trim() !== "") {
      const query = searchTerm.toLowerCase();
      rows = rows.filter((row) => {
        return Object.values(row.properties).some((val) =>
          String(val).toLowerCase().includes(query)
        );
      });
    }

    // Sort column logic
    if (sortField) {
      rows.sort((a, b) => {
        let valA = a.properties[sortField];
        let valB = b.properties[sortField];

        if (valA === undefined) return 1;
        if (valB === undefined) return -1;

        if (typeof valA === "number" && typeof valB === "number") {
          return sortDirection === "asc" ? valA - valB : valB - valA;
        }

        valA = String(valA).toLowerCase();
        valB = String(valB).toLowerCase();

        if (valA < valB) return sortDirection === "asc" ? -1 : 1;
        if (valA > valB) return sortDirection === "asc" ? 1 : -1;
        return 0;
      });
    }

    return rows;
  }, [tableRows, searchTerm, sortField, sortDirection]);

  // Jump/Locate specific clicked row item on Map
  const locateFeatureOnMap = (row: any) => {
    const geom = row.geometry;
    if (!geom) return;

    let targetCoord: [number, number] | null = null;

    if (geom.type === "Point") {
      targetCoord = [geom.coordinates[1], geom.coordinates[0]]; // Lat, Lon
    } else if (geom.type === "LineString") {
      // Use middle point of the LineString
      const midIdx = Math.floor(geom.coordinates.length / 2);
      targetCoord = [geom.coordinates[midIdx][1], geom.coordinates[midIdx][0]];
    } else if (geom.type === "Polygon") {
      // Use average center of the polygon
      let sumLat = 0, sumLon = 0, count = 0;
      geom.coordinates[0]?.forEach((c: number[]) => {
        sumLon += c[0];
        sumLat += c[1];
        count++;
      });
      if (count > 0) {
        targetCoord = [sumLat / count, sumLon / count];
      }
    }

    if (targetCoord) {
      onFeatureHighlight(targetCoord, row.properties);
    }
  };

  // Export properties registry to downloadable CSV format
  const exportToCSV = () => {
    if (tableRows.length === 0) return;

    const headersLine = tableHeaders.join(",");
    const csvContent = tableRows.map((row) => {
      return tableHeaders.map((header) => {
        const val = row.properties[header];
        if (val === undefined) return "";
        // Clean double quotes or commas for standard CSV parsing safety
        return `"${String(val).replace(/"/g, '""')}"`;
      }).join(",");
    });

    const fullCsv = [headersLine, ...csvContent].join("\n");
    const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), fullCsv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `${activeLayer?.name.toLowerCase().replace(/\s+/g, "_") || "tabla_atributos"}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex flex-col h-full bg-sdi-slate-card border border-sdi-slate-border rounded-xl overflow-hidden shadow-xl text-slate-100 font-sans">
      {/* Title Header Toolbar */}
      <div className="bg-sdi-slate-darker p-4 border-b border-sdi-slate-border flex flex-col md:flex-row md:items-center justify-between gap-3 text-left">
        <div className="flex items-center space-x-2">
          <Table className="w-5 h-5 text-sdi-blue shrink-0" />
          <div>
            <h2 className="font-bold text-sm uppercase tracking-wider text-slate-100">Tabla de Atributos Alfanuméricos</h2>
            <p className="text-[10px] text-sdi-slate-mute">Atributos registrados en la base geoespacial unificada</p>
          </div>
        </div>

        {/* Filters and export actions */}
        <div className="flex items-center space-x-3">
          {activeLayer && (
            <>
              {/* Search text filter container */}
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-sdi-slate-mute" />
                <input
                  type="text"
                  placeholder="Filtrar atributos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="bg-sdi-slate-bg border border-sdi-slate-border rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-100 placeholder-sdi-slate-mute focus:outline-none focus:border-sdi-blue w-48 font-medium"
                />
              </div>

              {/* Export to CSV btn */}
              <button
                onClick={exportToCSV}
                className="bg-sdi-slate-bg hover:bg-sdi-slate-hover text-emerald-400 border border-sdi-slate-border px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition cursor-pointer"
                title="Descargar base CSV"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Exportar CSV</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Main Table Spreadsheet Display screen */}
      <div className="flex-1 overflow-auto min-h-[140px]">
        {!activeLayer ? (
          <div className="flex flex-col items-center justify-center h-full p-8 text-sdi-slate-mute">
            <Table className="w-8 h-8 opacity-20 mb-2" />
            <p className="text-xs italic text-sdi-slate-mute">No hay ninguna capa activa para inspección.</p>
            <p className="text-[10px] text-sdi-slate-mute mt-1 max-w-xs text-center leading-relaxed">
              Toca o resalta una capa en el catálogo lateral de cartografía digital para cargar automáticamente su base de datos tabular.
            </p>
          </div>
        ) : processedRows.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full p-8 text-sdi-slate-mute italic">
            <Search className="w-6 h-6 opacity-30 mb-2" />
            <p className="text-xs">Ningún registro coincide con el filtro de búsqueda.</p>
          </div>
        ) : (
          <table className="w-full text-left border-collapse text-xs font-mono select-none">
            <thead>
              <tr className="bg-sdi-slate-darker text-sdi-slate-mute border-b border-sdi-slate-border sticky top-0 min-h-[36px]">
                <th className="py-2.5 px-3 text-sdi-slate-mute">Acciones</th>
                {tableHeaders.map((header) => (
                  <th
                    key={header}
                    onClick={() => handleSort(header)}
                    className="py-2.5 px-4 font-semibold text-[10px] uppercase text-sdi-slate-mute hover:text-sdi-blue hover:bg-sdi-slate-bg cursor-pointer select-none transition min-w-[120px]"
                  >
                    <div className="flex items-center space-x-1.5 justify-start">
                      <span>{header}</span>
                      <ArrowUpDown className="w-3 h-3 opacity-60" />
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {processedRows.map((row) => (
                <tr
                  key={row.index}
                  className="border-b border-sdi-slate-border/40 hover:bg-sdi-slate-darker/60 transition"
                >
                  <td className="py-2 px-3">
                    <button
                      onClick={() => locateFeatureOnMap(row)}
                      className="p-1 rounded bg-sdi-slate-bg border border-sdi-slate-border text-sdi-blue hover:text-white hover:bg-sdi-slate-hover transition flex items-center justify-center cursor-pointer"
                      title="Navegar a este elemento"
                    >
                      <MapPin className="w-3.5 h-3.5" />
                    </button>
                  </td>
                  {tableHeaders.map((header) => {
                    const value = row.properties[header];
                    return (
                      <td
                        key={header}
                        className="py-2 px-4 text-[11px] text-slate-300 whitespace-nowrap overflow-hidden text-ellipsis max-w-xs"
                      >
                        {value !== undefined ? String(value) : <span className="text-slate-600 font-mono">-</span>}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Row counter status tracking */}
      {activeLayer && (
        <div className="bg-sdi-slate-darker p-2 border-t border-sdi-slate-border px-4 flex justify-between items-center text-[10px] font-mono text-sdi-slate-mute">
          <span>Mostrando: <strong>{processedRows.length}</strong> de {tableRows.length} entidades</span>
          <span>Capa: <strong className="text-sdi-blue">{activeLayer.name}</strong></span>
        </div>
      )}
    </div>
  );
}

import React, { useState, useRef, useEffect } from "react";
import { GISLayer, Message } from "../types";
import { Brain, Send, Bot, Sparkles, AlertCircle, RefreshCw, Palette, HelpCircle } from "lucide-react";

interface AISpatialConsultantProps {
  activeLayer: GISLayer | null;
  onApplyStyleSuggestion: (layerId: string, style: { fillColor?: string, color?: string, weight?: number, opacity?: number }) => void;
}

export default function AISpatialConsultant({
  activeLayer,
  onApplyStyleSuggestion
}: AISpatialConsultantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "model",
      text: "¡Hola! Soy tu asistente de Geoprocesamiento e IDE Inteligente. Selecciona una capa cartográfica en el catálogo y haz clic en **Analizar Capa** para extraer información, correlaciones de atributos, interpretaciones espaciales u obtener esquemas de estilo personalizados.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [userInput, setUserInput] = useState("");
  const [sendingMessage, setSendingMessage] = useState(false);
  const [analysisLoading, setAnalysisLoading] = useState(false);
  const [suggestedStyles, setSuggestedStyles] = useState<any | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);

  // Smooth scroll chats to bottom on updates
  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [messages]);

  // Handle standard prompt query send
  const triggerUserQuery = async (customPrompt?: string) => {
    const textToSend = customPrompt || userInput;
    if (!textToSend.trim() || sendingMessage) return;

    // Append user input to window chat state
    const userMsg: Message = {
      role: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setMessages((prev) => [...prev, userMsg]);
    setUserInput("");
    setSendingMessage(true);

    try {
      // Gather metadata sample to send with payload
      let sampleAttributes: any[] = [];
      if (activeLayer?.geojson?.features) {
        sampleAttributes = activeLayer.geojson.features.slice(0, 3).map((f: any) => f.properties || {});
      }

      const response = await fetch("/api/gemini/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          layerName: activeLayer?.name,
          geometryType: activeLayer?.type,
          geometryCount: activeLayer?.metadata?.count || 0,
          attributes: sampleAttributes,
          prompt: textToSend
        }),
      });

      const data = await response.json();
      if (data.success) {
        setMessages((prev) => [
          ...prev,
          {
            role: "model",
            text: data.analysis,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
        if (data.suggestedStyles) {
          setSuggestedStyles(data.suggestedStyles);
        }
      } else {
        setMessages((prev) => [
          ...prev,
          {
            role: "model",
            text: `Lo siento, ocurrió un error procesando tu solicitud: ${data.message || "Falla de red."}`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
      }
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          role: "model",
          text: "Lo siento, no pude establecer conexión con la IA de geoprocesamiento.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setSendingMessage(false);
    }
  };

  // Preset button action: automated full GIS layer analyzer
  const handleFullLayerAnalysis = async () => {
    if (!activeLayer) return;
    setAnalysisLoading(true);

    try {
      const promptText = `Haz un análisis integral detallado de la capa cartográfica '${activeLayer.name}'. Explica qué representan los atributos, cómo influyen en el análisis territorial y sugiere directrices de geoprocesamiento aplicables.`;
      await triggerUserQuery(promptText);
    } finally {
      setAnalysisLoading(false);
    }
  };

  // Execute styling modification from Gemini suggestion
  const applyAIPalette = () => {
    if (!activeLayer || !suggestedStyles) return;
    onApplyStyleSuggestion(activeLayer.id, {
      fillColor: suggestedStyles.fillColor,
      color: suggestedStyles.color,
      weight: suggestedStyles.weight,
      opacity: suggestedStyles.opacity
    });

    // Notify user in chat
    setMessages((prev) => [
      ...prev,
      {
        role: "model",
        text: `🎨 **Paleta de Capa Aplicada**: He actualizado automáticamente el estilo visual de la capa **'${activeLayer.name}'** con la sugerencia estilística de la IA:\n- Color de línea: \`${suggestedStyles.color}\`\n- Color de fondo: \`${suggestedStyles.fillColor}\`\n- Grosor: \`${suggestedStyles.weight}px\``,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
    setSuggestedStyles(null);
  };

  return (
    <div className="flex flex-col h-full bg-sdi-slate-card border border-sdi-slate-border rounded-xl overflow-hidden shadow-xl text-slate-100 font-sans">
      {/* Consultant Header */}
      <div className="bg-sdi-slate-darker p-4 border-b border-sdi-slate-border flex items-center justify-between text-left">
        <div className="flex items-center space-x-2">
          <Brain className="w-5 h-5 text-emerald-400 shrink-0" />
          <div>
            <h2 className="font-bold text-sm uppercase tracking-wider text-slate-100">Consultor de Datos Espaciales IA</h2>
            <p className="text-[10px] text-sdi-slate-mute">Modelos Gemini cognitivos para geoprocesamiento de IDE</p>
          </div>
        </div>
        <Bot className="w-5 h-5 text-emerald-400 opacity-80" />
      </div>

      {/* Layer selector summary reminder */}
      <div className="bg-sdi-slate-bg p-2.5 px-4 border-b border-sdi-slate-border text-xs text-sdi-slate-mute flex items-center justify-between text-left">
        {activeLayer ? (
          <div className="flex items-center space-x-2 truncate">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
            <span className="truncate">Capa Activa: <strong className="text-sdi-blue font-mono font-bold">{activeLayer.name}</strong></span>
          </div>
        ) : (
          <div className="flex items-center space-x-2 text-rose-400">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            <span>Sin capa activa seleccionada para análisis de IA</span>
          </div>
        )}

        {activeLayer && (
          <button
            onClick={handleFullLayerAnalysis}
            disabled={analysisLoading || sendingMessage}
            className="bg-emerald-600/10 hover:bg-emerald-600/25 border border-emerald-500/30 text-emerald-400 px-2 py-0.5 rounded text-[10px] font-bold transition flex items-center space-x-1 shrink-0 cursor-pointer"
          >
            <RefreshCw className={`w-2.5 h-2.5 mr-0.5 ${analysisLoading ? "animate-spin" : ""}`} />
            <span>Analizar Capa</span>
          </button>
        )}
      </div>

      {/* Chat messages viewport */}
      <div ref={containerRef} className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[400px] min-h-[140px]">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"} animate-fade-in`}
          >
            <div
              className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed border text-left ${
                msg.role === "user"
                  ? "bg-sdi-blue/10 border-sdi-blue/20 text-slate-100 rounded-tr-none"
                  : "bg-sdi-slate-bg border-sdi-slate-border/80 text-slate-200 rounded-tl-none whitespace-pre-wrap"
              }`}
            >
              <div className="flex items-center space-x-1 mb-1 relative">
                {msg.role === "model" ? (
                  <Bot className="w-3.5 h-3.5 text-emerald-400" />
                ) : null}
                <span className="font-bold text-[9px] uppercase tracking-wider text-sdi-slate-mute">
                  {msg.role === "user" ? "Tú" : "Gemini GIS Advisor"}
                </span>
                <span className="text-[8px] text-sdi-slate-mute absolute right-0 font-mono">
                  {msg.timestamp}
                </span>
              </div>
              <p className="mt-1 leading-normal break-words">{msg.text}</p>
            </div>
          </div>
        ))}

        {/* Dynamic style suggestion anchor panel */}
        {suggestedStyles && (
          <div className="bg-sdi-slate-darker p-3 rounded-xl border border-emerald-500/30 text-left animate-pulse space-y-2 max-w-[85%] rounded-tl-none text-xs">
            <div className="flex items-center space-x-1">
              <Sparkles className="w-3.5 h-3.5 text-emerald-405" />
              <span className="font-bold text-[10px] text-emerald-400 uppercase tracking-widest">Sugerencia de Capa</span>
            </div>
            <p className="text-[11px] text-slate-300">
              He compuesto un estilo gráfico optimizado para la capa <strong>'{activeLayer?.name}'</strong> basado en sus propiedades geográficas.
            </p>
            <div className="flex items-center space-x-2 bg-sdi-slate-bg p-1.5 rounded border border-sdi-slate-border text-[10px] font-mono justify-between">
              <div className="flex items-center space-x-1">
                <span className="w-3 h-3 rounded-full border border-slate-100" style={{ backgroundColor: suggestedStyles.fillColor }} />
                <span>Relleno ID</span>
              </div>
              <div className="flex items-center space-x-1">
                <span className="w-3 h-3 rounded-full border border-slate-100" style={{ backgroundColor: suggestedStyles.color }} />
                <span>Borde</span>
              </div>
              <span>Peso: {suggestedStyles.weight}px</span>
            </div>
            <button
              onClick={applyAIPalette}
              className="w-full bg-emerald-600 hover:bg-emerald-700 transition font-bold py-1.5 rounded-lg text-slate-100 text-[10px] flex items-center justify-center space-x-1 uppercase cursor-pointer"
            >
              <Palette className="w-3 h-3" />
              <span>Aplicar Paleta IA a Capa</span>
            </button>
          </div>
        )}

        {sendingMessage && (
          <div className="flex justify-start">
            <div className="bg-sdi-slate-bg border border-sdi-slate-border rounded-xl rounded-tl-none p-3 max-w-[80%] text-xs flex items-center space-x-2 text-sdi-slate-mute">
              <div className="flex space-x-1">
                <div className="w-1.5 h-1.5 bg-sdi-blue rounded-full animate-bounce" />
                <div className="w-1.5 h-1.5 bg-sdi-blue rounded-full animate-bounce [animation-delay:0.2s]" />
                <div className="w-1.5 h-1.5 bg-sdi-blue rounded-full animate-bounce [animation-delay:0.4s]" />
              </div>
              <span>Gemini está procesando coordenadas...</span>
            </div>
          </div>
        )}
      </div>

      {/* User Prompt Input Tray */}
      <div className="bg-sdi-slate-card p-3.5 border-t border-sdi-slate-border flex items-center space-x-2">
        <input
          type="text"
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          placeholder={activeLayer ? "Pregunta a Gemini sobre esta capa..." : "Pregunta sobre geoprocesamiento/coordenadas..."}
          className="flex-1 bg-sdi-slate-bg border border-sdi-slate-border px-3 py-2 rounded-lg text-xs text-slate-200 placeholder-sdi-slate-mute focus:outline-none focus:border-sdi-blue font-medium"
          disabled={sendingMessage}
          onKeyDown={(e) => {
            if (e.key === "Enter") triggerUserQuery();
          }}
        />
        <button
          onClick={() => triggerUserQuery()}
          disabled={!userInput.trim() || sendingMessage}
          className="bg-sdi-blue hover:opacity-90 disabled:bg-sdi-slate-darker p-2.5 rounded-lg transition cursor-pointer text-sdi-slate-darker"
        >
          <Send className="w-4 h-4 text-sdi-slate-darker" />
        </button>
      </div>
    </div>
  );
}

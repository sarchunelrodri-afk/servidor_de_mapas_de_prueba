import React, { useState } from "react";
import { GISLayer, GeometryType } from "../types";
import {
  Compass,
  MapPin,
  Maximize,
  Sparkles,
  Calculator,
  Grid,
  TrendingUp,
  Spline
} from "lucide-react";

interface SpatialAnalysisProps {
  layers: GISLayer[];
  selectedLayerId: string | null;
  onAddLayer: (layer: GISLayer) => void;
  drawMode: "none" | "point" | "polygon";
  setDrawMode: (mode: "none" | "point" | "polygon") => void;
}

export default function SpatialAnalysis({
  layers,
  selectedLayerId,
  onAddLayer,
  drawMode,
  setDrawMode
}: SpatialAnalysisProps) {
  const [bufferDistanceKm, setBufferDistanceKm] = useState<number>(1.5);
  const [processingState, setProcessingState] = useState<string | null>(null);

  const activeLayer = layers.find((l) => l.id === selectedLayerId);

  // Math utility: Geodetic trigonometry to calculate a polygon circle (spatial buffer)
  const generateCoordinateBuffer = (lon: number, lat: number, radiusKm: number): number[][] => {
    const points: number[][] = [];
    const pointsCount = 31; // number of vertices to make a neat circle
    const earthRadius = 6371; // Earth physical radius in km

    for (let i = 0; i < pointsCount; i++) {
      const angle = (i * 360) / (pointsCount - 1);
      const angleRad = (angle * Math.PI) / 180;

      // Angular distance (rad)
      const dDivR = radiusKm / earthRadius;
      const latRad = (lat * Math.PI) / 180;
      const lonRad = (lon * Math.PI) / 180;

      const bufferLatRad = Math.asin(
        Math.sin(latRad) * Math.cos(dDivR) +
        Math.cos(latRad) * Math.sin(dDivR) * Math.cos(angleRad)
      );

      const bufferLonRad =
        lonRad +
        Math.atan2(
          Math.sin(angleRad) * Math.sin(dDivR) * Math.cos(latRad),
          Math.cos(dDivR) - Math.sin(latRad) * Math.sin(bufferLatRad)
        );

      points.push([
        (bufferLonRad * 180) / Math.PI, // longitude
        (bufferLatRad * 180) / Math.PI  // latitude
      ]);
    }
    return points;
  };

  // Perform buffer analysis
  const handleExecuteBufferAnalysis = () => {
    if (!activeLayer) {
      alert("Por favor, seleccione una capa de origen en el catálogo para iniciar la georreferenciación de buffer.");
      return;
    }

    setProcessingState("Calculando área de influencia...");

    setTimeout(() => {
      try {
        const bufferFeatures: any[] = [];

        if (activeLayer.geojson?.features) {
          activeLayer.geojson.features.forEach((feat: any) => {
            const geom = feat.geometry;
            const props = feat.properties || {};

            if (geom.type === "Point") {
              const [lon, lat] = geom.coordinates;
              const circleCoords = generateCoordinateBuffer(lon, lat, bufferDistanceKm);

              bufferFeatures.push({
                type: "Feature",
                properties: {
                  ...props,
                  nombre: `Buffer (${bufferDistanceKm}km) de ${props.nombre || "Estación"}`,
                  categoria: "Área de Influencia",
                  parent_layer_id: activeLayer.id,
                  buffer_radius_km: bufferDistanceKm,
                  valor: Math.round(props.valor * 1.2 || 10)
                },
                geometry: {
                  type: "Polygon",
                  coordinates: [circleCoords]
                }
              });
            } else if (geom.type === "LineString") {
              // Simulating line buffering by buffering its vertices for demonstration
              geom.coordinates.forEach((coord: number[], idx: number) => {
                const [lon, lat] = coord;
                const circleCoords = generateCoordinateBuffer(lon, lat, bufferDistanceKm);
                bufferFeatures.push({
                  type: "Feature",
                  properties: {
                    ...props,
                    nombre: `Área de Influencia Vial (Vértice ${idx + 1})`,
                    categoria: "Área de Influencia",
                    parent_layer_id: activeLayer.id,
                    buffer_radius_km: bufferDistanceKm,
                    valor: Math.round(props.valor * 0.5 || 5)
                  },
                  geometry: {
                    type: "Polygon",
                    coordinates: [circleCoords]
                  }
                });
              });
            }
          });
        }

        if (bufferFeatures.length === 0) {
          alert("No se localizaron puntos o vértices procesables en la capa activa para formular zonas buffer.");
          setProcessingState(null);
          return;
        }

        const bufferGeoJSON = {
          type: "FeatureCollection",
          features: bufferFeatures
        };

        const bufferLayer: GISLayer = {
          id: `usr-buffer-${Date.now()}`,
          name: `Buffer ${bufferDistanceKm}km: ${activeLayer.name}`,
          type: "Polygon",
          geojson: bufferGeoJSON,
          visible: true,
          opacity: 0.5,
          color: "#ea580c", // orange-600
          fillColor: "#ffedd5", // orange-100
          weight: 1.5,
          category: "usuario",
          description: `Área de influencia geodésica concéntrica de ${bufferDistanceKm} km aplicada sobre los nodos de la capa '${activeLayer.name}'.`,
          metadata: {
            count: bufferFeatures.length,
            projection: "WGS 84 (EPSG:4326)",
            dateAdded: new Date().toLocaleDateString(),
            source: "Geoprocesamiento Vectorial IDE",
          }
        };

        onAddLayer(bufferLayer);
      } catch (err) {
        console.error("Buffer calculation error:", err);
        alert("Ocurrió un error matemático al procesar los vectores espaciales.");
      } finally {
        setProcessingState(null);
      }
    }, 450);
  };

  // Perform average geographic centroid extraction
  const handleCalculateLayerCentroid = () => {
    if (!activeLayer) {
      alert("Por favor seleccione primero una capa de origen en el Catálogo.");
      return;
    }

    setProcessingState("Buscando centro de masa geográfico...");

    setTimeout(() => {
      try {
        let sumX = 0;
        let sumY = 0;
        let coordsCount = 0;

        if (activeLayer.geojson?.features) {
          activeLayer.geojson.features.forEach((feat: any) => {
            const geom = feat.geometry;
            if (!geom) return;

            if (geom.type === "Point") {
              const [lon, lat] = geom.coordinates;
              sumX += lon;
              sumY += lat;
              coordsCount++;
            } else if (geom.type === "LineString") {
              geom.coordinates.forEach((coord: number[]) => {
                sumX += coord[0];
                sumY += coord[1];
                coordsCount++;
              });
            } else if (geom.type === "Polygon") {
              // Outer ring vertices
              geom.coordinates[0]?.forEach((coord: number[]) => {
                sumX += coord[0];
                sumY += coord[1];
                coordsCount++;
              });
            }
          });
        }

        if (coordsCount === 0) {
          alert("No se encontraron coordenadas válidas para extraer el baricentro.");
          setProcessingState(null);
          return;
        }

        const avgLon = sumX / coordsCount;
        const avgLat = sumY / coordsCount;

        const centroidGeoJSON = {
          type: "FeatureCollection",
          features: [
            {
              type: "Feature",
              properties: {
                id: `centroid-${Date.now()}`,
                nombre: `Centroide de ${activeLayer.name}`,
                categoria: "Centro de Gravedad",
                parent_layer_id: activeLayer.id,
                coordenadas_dec: `${avgLat.toFixed(5)}, ${avgLon.toFixed(5)}`,
                valor: coordsCount,
                descripcion: `Centro de gravedad espacial calculado haciendo un promedio ponderado de los ${coordsCount} nodos vectoriales totales ubicados.`
              },
              geometry: {
                type: "Point",
                coordinates: [avgLon, avgLat]
              }
            }
          ]
        };

        const centroidLayer: GISLayer = {
          id: `usr-centroid-${Date.now()}`,
          name: `Centroide: ${activeLayer.name}`,
          type: "Point",
          geojson: centroidGeoJSON,
          visible: true,
          opacity: 0.95,
          color: "#9333ea", // purple-600
          fillColor: "#f3e8ff", // purple-100
          weight: 4,
          category: "usuario",
          description: `Punto baricentro geográfico resultante del promedio vectorial de los elementos contenidos en '${activeLayer.name}'.`,
          metadata: {
            count: 1,
            projection: "WGS 84 (EPSG:4326)",
            dateAdded: new Date().toLocaleDateString(),
            source: "Calculador de Gravedad Espacial",
          }
        };

        onAddLayer(centroidLayer);
      } catch (err) {
        console.error(err);
        alert("Excepción durante la recopilación del baricentro.");
      } finally {
        setProcessingState(null);
      }
    }, 400);
  };

  return (
    <div className="flex flex-col h-full bg-sdi-slate-card border border-sdi-slate-border rounded-xl overflow-hidden shadow-xl text-slate-100">
      {/* Geoprocessing Header */}
      <div className="bg-sdi-slate-darker p-4 border-b border-sdi-slate-border flex items-center space-x-2">
        <Compass className="w-5 h-5 text-sdi-blue" />
        <h2 className="font-semibold text-sm uppercase tracking-wider text-slate-100 mb-0">Herramientas GIS y Digitalización</h2>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-5">
        {/* Vectorization Hand Drawing Panel */}
        <div className="space-y-3 bg-sdi-slate-darker/40 p-3.5 rounded-xl border border-sdi-slate-border text-left">
          <div className="flex items-center space-x-1.5 border-b border-sdi-slate-border/80 pb-2">
            <Spline className="w-4.5 h-4.5 text-amber-500" />
            <h3 className="text-xs font-bold text-slate-200">Digitalización en Pantalla (Dibuja)</h3>
          </div>
          <p className="text-[10px] text-sdi-slate-mute leading-normal">
            Crea geometrías vectoriales dibujando con clics directamente sobre el mapa base actual para añadir elementos simulados.
          </p>
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              onClick={() => setDrawMode(drawMode === "point" ? "none" : "point")}
              className={`p-2 rounded-lg text-xs font-semibold flex items-center justify-center space-x-1.5 transition cursor-pointer ${
                drawMode === "point"
                  ? "bg-amber-500 text-slate-950 font-bold"
                  : "bg-sdi-slate-bg hover:bg-sdi-slate-hover text-slate-200 border border-sdi-slate-border"
              }`}
            >
              <MapPin className="w-3.5 h-3.5" />
              <span>{drawMode === "point" ? "Capturando..." : "Trazar Punto"}</span>
            </button>
            <button
              onClick={() => setDrawMode(drawMode === "polygon" ? "none" : "polygon")}
              className={`p-2 rounded-lg text-xs font-semibold flex items-center justify-center space-x-1.5 transition cursor-pointer ${
                drawMode === "polygon"
                  ? "bg-amber-500 text-slate-950 font-bold"
                  : "bg-sdi-slate-bg hover:bg-sdi-slate-hover text-slate-200 border border-sdi-slate-border"
              }`}
            >
              <Maximize className="w-3.5 h-3.5" />
              <span>{drawMode === "polygon" ? "Capturando..." : "Trazar Polígono"}</span>
            </button>
          </div>
        </div>

        {/* Selected Layer Informative Panel */}
        <div className="bg-sdi-slate-bg p-3 rounded-lg border border-sdi-slate-border text-left">
          <span className="text-[9px] font-bold text-sdi-slate-mute block uppercase tracking-wide mb-1">Capa Activa de Análisis:</span>
          {activeLayer ? (
            <div>
              <p className="text-xs font-bold text-sdi-blue truncate">{activeLayer.name}</p>
              <p className="text-[10px] text-sdi-slate-mute mt-0.5">
                Geometría: <span className="text-slate-200 font-mono">{activeLayer.type}</span> | Nodos: <span className="text-slate-200 font-mono">{activeLayer.metadata.count}</span>
              </p>
            </div>
          ) : (
            <p className="text-xs text-rose-400 italic">No ha seleccionado ninguna capa. Marque una en el catálogo para habilitar transacciones espaciales.</p>
          )}
        </div>

        {/* Spatial Buffer (Area de Influencia) */}
        <div className="space-y-3 bg-sdi-slate-darker/40 p-3.5 rounded-xl border border-sdi-slate-border text-left">
          <div className="flex items-center space-x-1.5 border-b border-sdi-slate-border/80 pb-2">
            <Compass className="w-4.5 h-4.5 text-sdi-blue" />
            <h3 className="text-xs font-bold text-slate-200">Zonas de Influencia (Buffers)</h3>
          </div>
          <p className="text-[10px] text-sdi-slate-mute leading-normal">
            Calcula polígonos circulares de cobertura espacial concéntrica (amortiguamiento) basados en una distancia radial parametrizada en kilómetros.
          </p>

          <div className="space-y-2">
            <div className="flex justify-between text-xs text-slate-300 font-mono">
              <span>Distancia Buffer:</span>
              <span className="text-sdi-blue font-bold">{bufferDistanceKm} km</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="10"
              step="0.5"
              value={bufferDistanceKm}
              onChange={(e) => setBufferDistanceKm(parseFloat(e.target.value))}
              className="w-full accent-sdi-blue cursor-pointer bg-sdi-slate-bg rounded"
              disabled={!activeLayer}
            />
          </div>

          <button
            onClick={handleExecuteBufferAnalysis}
            disabled={!activeLayer || !!processingState}
            className="w-full bg-sdi-blue hover:opacity-90 disabled:bg-sdi-slate-bg text-sdi-slate-darker font-bold py-2 rounded-lg text-xs tracking-wide transition shadow flex items-center justify-center space-x-2 shrink-0 cursor-pointer"
          >
            <Compass className="w-4 h-4 text-sdi-slate-darker" />
            <span>Calcular Influencia</span>
          </button>
        </div>

        {/* Baricentro (Mass Centroids) */}
        <div className="space-y-3 bg-sdi-slate-darker/40 p-3.5 rounded-xl border border-sdi-slate-border text-left">
          <div className="flex items-center space-x-1.5 border-b border-sdi-slate-border/80 pb-2">
            <Calculator className="w-4.5 h-4.5 text-purple-400" />
            <h3 className="text-xs font-bold text-slate-200">Baricentro Espacial (Centroide)</h3>
          </div>
          <p className="text-[10px] text-sdi-slate-mute leading-normal">
            Extrae el centro de masa geográfico promedio de todos los nodos contenidos en la capa seleccionada. Añade un punto indicador de análisis.
          </p>

          <button
            onClick={handleCalculateLayerCentroid}
            disabled={!activeLayer || !!processingState}
            className="w-full bg-purple-600 hover:bg-purple-705 disabled:bg-sdi-slate-bg text-slate-100 font-bold py-2 rounded-lg text-xs tracking-wide transition shadow flex items-center justify-center space-x-2 shrink-0 cursor-pointer"
          >
            <Calculator className="w-4 h-4 text-slate-100" />
            <span>Calcular Centroide</span>
          </button>
        </div>
      </div>

      {/* Loading GIS Overlay */}
      {processingState && (
        <div className="bg-sdi-slate-darker/95 py-3 px-4 border-t border-sdi-slate-border flex items-center space-x-3 text-xs text-slate-300 animate-pulse font-mono justify-center">
          <div className="w-4 h-4 border-2 border-sdi-blue border-t-sdi-slate-darker rounded-full animate-spin" />
          <span>{processingState}</span>
        </div>
      )}
    </div>
  );
}

import { useEffect, useRef, useState } from "react";
import L from "leaflet";
import { GISLayer, BaseMap } from "../types";
import { Layers, MapPin, Minimize, HelpCircle, Eye, EyeOff, Sparkles, Navigation } from "lucide-react";

// Standard base map configurations
const BASE_MAPS: BaseMap[] = [
  {
    id: "dark",
    name: "CartoDB Dark Matter",
    url: "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
    style: "dark"
  },
  {
    id: "osm",
    name: "OpenStreetMap",
    url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    style: "topo"
  },
  {
    id: "satellite",
    name: "Esri Satellite Imagery",
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    attribution: "Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community",
    style: "satellite"
  }
];

interface MapViewerProps {
  layers: GISLayer[];
  selectedLayerId: string | null;
  onFeatureSelect: (properties: any, geometry: any) => void;
  drawMode: "none" | "point" | "polygon";
  setDrawMode: (mode: "none" | "point" | "polygon") => void;
  onDrawingComplete: (geojsonFeature: any) => void;
  centerCoordinates: [number, number];
  zoomLevel: number;
}

export default function MapViewer({
  layers,
  selectedLayerId,
  onFeatureSelect,
  drawMode,
  setDrawMode,
  onDrawingComplete,
  centerCoordinates,
  zoomLevel
}: MapViewerProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const geoJSONLayersGroupRef = useRef<L.FeatureGroup | null>(null);
  const drawnFeaturesGroupRef = useRef<L.FeatureGroup | null>(null);

  const [activeBaseMap, setActiveBaseMap] = useState<string>("dark");
  const [hoveredFeatureInfo, setHoveredFeatureInfo] = useState<string | null>(null);
  const [temporaryPoints, setTemporaryPoints] = useState<[number, number][]>([]);

  // Initialize standard Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Cleanup potential previous instance
    if (mapInstanceRef.current) {
      mapInstanceRef.current.remove();
      mapInstanceRef.current = null;
    }

    const map = L.map(mapContainerRef.current, {
      center: centerCoordinates,
      zoom: zoomLevel,
      zoomControl: false // Customizing controls layout below
    });

    mapInstanceRef.current = map;

    // Put standard zoom controls on top-right instead of defaults
    L.control.zoom({ position: "topright" }).addTo(map);

    // Initial tile base layer setup
    const selectedBase = BASE_MAPS.find((b) => b.id === activeBaseMap) || BASE_MAPS[0];
    const tiles = L.tileLayer(selectedBase.url, {
      attribution: selectedBase.attribution,
      maxZoom: 19
    }).addTo(map);
    tileLayerRef.current = tiles;

    // FeatureGroups for mapping overlays
    const geoGroups = L.featureGroup().addTo(map);
    geoJSONLayersGroupRef.current = geoGroups;

    const drawnGroup = L.featureGroup().addTo(map);
    drawnFeaturesGroupRef.current = drawnGroup;

    // Leaflet icon path fixes (crucial for showing markers correctly)
    delete (L.Icon.Default.prototype as any)._getIconUrl;
    L.Icon.Default.mergeOptions({
      iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
      iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
      shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
    });

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Update center and zoom when programmatically shifted
  useEffect(() => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setView(centerCoordinates, zoomLevel);
    }
  }, [centerCoordinates, zoomLevel]);

  // Handle Base Map tile Swapping
  useEffect(() => {
    if (!mapInstanceRef.current || !tileLayerRef.current) return;
    const selectedBase = BASE_MAPS.find((b) => b.id === activeBaseMap) || BASE_MAPS[0];
    mapInstanceRef.current.removeLayer(tileLayerRef.current);
    const newTiles = L.tileLayer(selectedBase.url, {
      attribution: selectedBase.attribution,
      maxZoom: 19
    }).addTo(mapInstanceRef.current);
    tileLayerRef.current = newTiles;
  }, [activeBaseMap]);

  // Load and Render GIS Layers overlays on map
  useEffect(() => {
    const map = mapInstanceRef.current;
    const geoGroup = geoJSONLayersGroupRef.current;
    if (!map || !geoGroup) return;

    // Clear previous geometries
    geoGroup.clearLayers();

    layers.forEach((layer) => {
      if (!layer.visible) return;

      // Define standard vector styling
      const layerStyle = {
        color: layer.color,
        fillColor: layer.fillColor,
        weight: layer.weight,
        opacity: layer.opacity,
        fillOpacity: layer.opacity * 0.6
      };

      // Handle the case of point layers vs polygon styles
      const geojsonObj = L.geoJSON(layer.geojson, {
        style: (feature) => {
          // If thematic rendering is selected, compute varying color fills
          if (layer.activeThematicField && feature?.properties) {
            const val = feature.properties[layer.activeThematicField];
            if (typeof val === "number") {
              // High performance color classification scale
              const colors = ["#fef08a", "#fde047", "#eab308", "#ca8a04", "#854d0e"]; // Yellows-browns
              const index = Math.min(Math.floor((val / 100) * colors.length), colors.length - 1);
              return {
                ...layerStyle,
                fillColor: colors[index >= 0 ? index : 2],
              };
            }
          }
          return layerStyle;
        },
        pointToLayer: (feature, latlng) => {
          // Choose marker design
          return L.circleMarker(latlng, {
            radius: layer.weight * 2 + 2,
            fillColor: layer.fillColor,
            color: layer.color,
            weight: 1.5,
            opacity: layer.opacity,
            fillOpacity: layer.opacity * 0.7
          });
        },
        onEachFeature: (feature, leafletLayer) => {
          // Bind tooltip and standard handlers
          const props = feature.properties || {};
          const title = props.nombre || props.name || `Feature #${props.id || "ID"}`;
          leafletLayer.bindTooltip(title, {
            permanent: false,
            direction: "top"
          });

          // Style highlight on hover
          leafletLayer.on({
            mouseover: () => {
              setHoveredFeatureInfo(`${layer.name}: ${title}`);
              if (leafletLayer instanceof L.Path) {
                leafletLayer.setStyle({
                  weight: layer.weight + 2,
                  color: "#38bdf8" // bright cyan highlight outline
                });
              }
            },
            mouseout: () => {
              setHoveredFeatureInfo(null);
              if (leafletLayer instanceof L.Path) {
                // Restore standard styles
                geojsonObj.resetStyle(leafletLayer);
              }
            },
            click: (e) => {
              onFeatureSelect(props, feature.geometry);
              // Open popup content
              L.popup()
                .setLatLng(e.latlng)
                .setContent(`
                  <div class="p-2 text-xs text-slate-100 max-w-xs">
                    <h4 class="font-bold text-sky-400 mb-1 border-b border-slate-700 pb-1 text-sm">${title}</h4>
                    <p class="text-slate-300 italic mb-2">${props.descripcion || "Sin descripción adicional registrada."}</p>
                    <div class="grid grid-cols-2 gap-1 font-mono text-[10px] bg-slate-900/60 p-1.5 rounded border border-slate-700">
                      <span class="text-slate-400">Categoría:</span>
                      <span class="text-slate-200 font-semibold">${props.categoria || "N/D"}</span>
                      <span class="text-slate-400">Valor principal:</span>
                      <span class="text-sky-300 font-semibold">${props.valor !== undefined ? props.valor : "N/D"}</span>
                    </div>
                  </div>
                `)
                .openOn(map);
            }
          });
        }
      });

      geoGroup.addLayer(geojsonObj);
    });

    // Auto fit boundary of selected active layer if applicable
    if (selectedLayerId) {
      const activeLayer = layers.find((l) => l.id === selectedLayerId);
      if (activeLayer && activeLayer.visible && activeLayer.geojson) {
        try {
          const lGeo = L.geoJSON(activeLayer.geojson);
          const bounds = lGeo.getBounds();
          if (bounds.isValid()) {
            map.fitBounds(bounds, { padding: [40, 40] });
          }
        } catch (e) {
          console.error("Failed to fit bounds of selected layer:", e);
        }
      }
    }
  }, [layers, selectedLayerId]);

  // Handle manual GIS Layer drawing inputs (Point & Polygon)
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || drawMode === "none") {
      setTemporaryPoints([]);
      return;
    }

    const clickHandler = (e: L.LeafletMouseEvent) => {
      const { lat, lng } = e.latlng;

      if (drawMode === "point") {
        const pointFeature = {
          type: "Feature",
          properties: {
            id: `usr-pt-${Date.now()}`,
            nombre: `Punto Dibujado #${temporaryPoints.length + 1}`,
            categoria: "Modo Dibujo",
            valor: Math.round(Math.random() * 100),
            descripcion: `Punto capturado interactivamente en latitud ${lat.toFixed(6)}, longitud ${lng.toFixed(6)}`
          },
          geometry: {
            type: "Point",
            coordinates: [lng, lat]
          }
        };

        // Complete point draw instantly
        onDrawingComplete(pointFeature);
        setDrawMode("none");
      } else if (drawMode === "polygon") {
        const updatedPoints = [...temporaryPoints, [lat, lng] as [number, number]];
        setTemporaryPoints(updatedPoints);

        // Add visual anchor dot
        L.circleMarker(e.latlng, {
          radius: 6,
          fillColor: "#f59e0b", // yellow-500
          color: "#ffffff",
          weight: 1.5,
          opacity: 1,
          fillOpacity: 0.9
        }).addTo(drawnFeaturesGroupRef.current!);
      }
    };

    map.on("click", clickHandler);

    return () => {
      map.off("click", clickHandler);
    };
  }, [drawMode, temporaryPoints]);

  const finishPolygonDrawing = () => {
    if (temporaryPoints.length < 3) {
      alert("Se requieren al menos 3 vértices para formular un polígono espacial.");
      return;
    }

    // Wrap Leaflet Lat, Lng coordinates to GeoJSON standard [Long, Lat]
    const formattedCoordinates = temporaryPoints.map((pt) => [pt[1], pt[0]]);
    // Close the polygon ring automatically
    formattedCoordinates.push([temporaryPoints[0][1], temporaryPoints[0][0]]);

    const polygonFeature = {
      type: "Feature",
      properties: {
        id: `usr-poly-${Date.now()}`,
        nombre: `Polígono Dibujado #${Math.floor(Math.random() * 100)}`,
        categoria: "Modo Dibujo",
        valor: Math.round(formattedCoordinates.length * 15),
        descripcion: `Polígono capturado con ${temporaryPoints.length} vértices interactivamente por el usuario.`
      },
      geometry: {
        type: "Polygon",
        coordinates: [formattedCoordinates]
      }
    };

    // Clear visual temporary markers
    if (drawnFeaturesGroupRef.current) {
      drawnFeaturesGroupRef.current.clearLayers();
    }

    onDrawingComplete(polygonFeature);
    setDrawMode("none");
    setTemporaryPoints([]);
  };

  const cancelDrawing = () => {
    setDrawMode("none");
    setTemporaryPoints([]);
    if (drawnFeaturesGroupRef.current) {
      drawnFeaturesGroupRef.current.clearLayers();
    }
  };

  // Auto-focus map to default home view
  const bounceHome = () => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setView(centerCoordinates, zoomLevel);
    }
  };

  return (
    <div className="relative w-full h-full rounded-xl overflow-hidden border border-sdi-slate-border bg-sdi-slate-bg shadow-2xl">
      {/* Map Root Div */}
      <div id="leaflet-map-root" ref={mapContainerRef} className="w-full h-full z-10" />

      {/* Dynamic Hover Layer HUD Overlay */}
      {hoveredFeatureInfo && (
        <div className="absolute bottom-6 left-6 z-20 bg-sdi-slate-bg/95 border border-sdi-slate-border text-slate-50 px-3 py-1.5 rounded-lg text-xs font-mono shadow-lg backdrop-blur-md flex items-center space-x-2 antialiased animate-fade-in">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
          <span>{hoveredFeatureInfo}</span>
        </div>
      )}

      {/* Floating Basemap Selector Controls */}
      <div className="absolute top-4 left-4 z-20 flex flex-col space-y-2 bg-sdi-slate-card/90 hover:bg-sdi-slate-card p-2 rounded-lg border border-sdi-slate-border shadow-md backdrop-blur-sm transition">
        <div className="flex items-center space-x-1.5 border-b border-sdi-slate-border pb-1.5 px-1">
          <Layers className="w-3.5 h-3.5 text-sdi-blue" />
          <span className="text-[10px] font-bold text-sdi-slate-mute uppercase tracking-wider">Mapa Base</span>
        </div>
        <div className="flex flex-col space-y-1">
          {BASE_MAPS.map((mapOption) => (
            <button
              key={mapOption.id}
              onClick={() => setActiveBaseMap(mapOption.id)}
              className={`text-left px-2 py-1 rounded text-xs transition-all cursor-pointer ${
                activeBaseMap === mapOption.id
                  ? "bg-sdi-blue/10 border border-sdi-blue/30 text-sdi-blue font-medium"
                  : "text-slate-450 hover:text-slate-200 hover:bg-sdi-slate-hover"
              }`}
            >
              {mapOption.name}
            </button>
          ))}
        </div>
      </div>

      {/* Dynamic Drawing Indicator Floating Panel */}
      {drawMode !== "none" && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 bg-amber-500/95 text-slate-955 px-4 py-3 rounded-xl border border-amber-600 shadow-xl flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-4 animate-bounce max-w-md">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-4.5 h-4.5 text-slate-950 shrink-0" />
            <span className="text-xs font-semibold leading-tight">
              {drawMode === "point"
                ? "Haz clic sobre el mapa para plantar el marcador nuevo."
                : `Dibujando polígono (${temporaryPoints.length} vértices). Haz clic para añadir puntos.`}
            </span>
          </div>
          <div className="flex items-center space-x-2">
            {drawMode === "polygon" && temporaryPoints.length >= 3 && (
              <button
                onClick={finishPolygonDrawing}
                className="bg-slate-950 hover:bg-slate-900 text-slate-50 text-[10px] uppercase font-bold px-2.5 py-1.5 rounded-lg border border-slate-800 transition shadow cursor-pointer"
              >
                Concluir Polígono
              </button>
            )}
            <button
              onClick={cancelDrawing}
              className="bg-red-650 hover:bg-red-700 text-white text-[10px] uppercase font-bold px-2.5 py-1.5 rounded-lg transition shadow cursor-pointer"
            >
              Cancelar
            </button>
          </div>
        </div>
      )}

      {/* Quick Navigation Panel */}
      <div className="absolute bottom-4 right-4 z-20 flex space-x-2 bg-sdi-slate-bg/95 border border-sdi-slate-border p-1.5 rounded-lg shadow-lg backdrop-blur-md">
        <button
          onClick={bounceHome}
          title="Centrar Mapa General"
          className="p-1 px-2 rounded-lg text-sdi-slate-mute hover:text-slate-105 hover:bg-sdi-slate-hover transition flex items-center space-x-1 cursor-pointer"
        >
          <Minimize className="w-3.5 h-3.5" />
          <span className="text-[10px] font-medium">Reajustar Origen</span>
        </button>
      </div>

      {/* Tiny Map Information Overlay */}
      <div className="absolute top-4 right-16 z-20 bg-sdi-slate-bg/90 border border-sdi-slate-border p-1 px-2 rounded-lg text-[9px] font-mono text-sdi-slate-mute select-none shadow max-w-[120px] text-right">
        Coordenadas:
        <br />
        <span className="text-slate-300 font-bold">WGS 84 / LatLong</span>
      </div>
    </div>
  );
}

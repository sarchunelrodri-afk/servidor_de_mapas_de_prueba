import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Increase request size limit for large GeoJSON geometry layers
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Lazy initializer for Gemini client to prevent crashes if key is initially absent
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY_MISSING");
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// REST API Endpoints

// 1. Analyze geographic vector data (attributes / description) using Gemini
app.post("/api/gemini/analyze", async (req, res) => {
  try {
    const { layerName, attributes, geometryCount, geometryType, prompt } = req.body;

    let ai;
    try {
      ai = getGeminiClient();
    } catch {
      return res.status(200).json({
        success: false,
        message: "Clave de API de Gemini no disponible. Por favor, agregue 'GEMINI_API_KEY' en la pestaña Configuración > Secrets.",
        suggestedStyles: null
      });
    }

    const systemPrompt = `Eres un Ingeniero GIS senior y especialista en Infraestructuras de Datos Espaciales (IDE).
Ayudas al usuario a analizar capas de cartografía digital (GeoJSON).
Se te proporcionará información sobre una capa de mapa cargada en el portal:
- Nombre de la capa: ${layerName || "Desconocida"}
- Tipo de Geometría: ${geometryType || "Mezclada"}
- Cantidad de elementos (Features): ${geometryCount || 0}
- Muestra de la Tabla de Atributos: ${JSON.stringify(attributes || [])}

Tu tarea es:
1. Analizar el contenido de esta capa geográfica, qué representa y explicarlo de manera muy clara para un portal cartográfico profesional.
2. Identificar relaciones espaciales o de atributos de valor (ej: correlación entre población, áreas protegidas, infraestructura, etc.).
3. Sugerir 3 estilos de visualización web convenientes (colores hexadecimales, grosores de línea, opacidad) y clasificaciones choropleth factibles según los campos disponibles en la muestra.
4. Responder en español de manera profesional y estructurada con Markdown.`;

    const userMessage = prompt || "Dame un análisis general y recomendaciones GIS de esta capa cartográfica.";

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: userMessage,
      config: {
        systemInstruction: systemPrompt,
      },
    });

    const analysisText = response.text || "No se pudo generar un análisis.";

    // Let's also parse some structural style suggestions to help the frontend customize styling
    const stylePrompt = `Basado en la capa '${layerName}', geometría '${geometryType}' y tabla de atributos '${JSON.stringify(attributes)}', genera un JSON con sugerencias de estilo directo para Leaflet.
Ejemplo:
{
  "fillColor": "#3b82f6",
  "color": "#1d4ed8",
  "weight": 2,
  "opacity": 0.8,
  "fillOpacity": 0.5,
  "classificationField": "nombre_del_campo_segun_atributos"
}`;

    let suggestedStyles = null;
    try {
      const styleResponse = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: stylePrompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              fillColor: { type: Type.STRING },
              color: { type: Type.STRING },
              weight: { type: Type.INTEGER },
              opacity: { type: Type.NUMBER },
              fillOpacity: { type: Type.NUMBER },
              classificationField: { type: Type.STRING },
            },
            required: ["fillColor", "color", "weight", "opacity", "fillOpacity"],
          },
        },
      });

      if (styleResponse.text) {
        suggestedStyles = JSON.parse(styleResponse.text);
      }
    } catch (e) {
      console.error("Error generating style suggestions:", e);
    }

    res.json({
      success: true,
      analysis: analysisText,
      suggestedStyles,
    });
  } catch (error: any) {
    console.error("Error analyzing layer:", error);
    res.status(500).json({ success: false, error: error.message || "Error interno del servidor" });
  }
});

// 2. Draft dynamic cartography with natural language using Gemini
app.post("/api/gemini/generate-layer", async (req, res) => {
  try {
    const { theme } = req.body;
    if (!theme) {
      return res.status(400).json({ success: false, error: "El tema o idea de capa es requerido." });
    }

    let ai;
    try {
      ai = getGeminiClient();
    } catch {
      return res.status(200).json({
        success: false,
        message: "Clave de API de Gemini no disponible. No se puede generar la capa cartográfica por IA.",
        geojson: null
      });
    }

    const promptText = `Genera una capa cartográfica válida de tipo GeoJSON (RFC 7946) que represente la siguiente idea espacial: "${theme}".
Debe ser un "FeatureCollection" que resida en coordenadas reales lógicas (por ejemplo, si pide departamentos o ríos de Bolivia, usa coordenadas reales de Bolivia con Latitud entre -9.6 y -22.9, y Longitud entre -57.4 y -69.6. Si pide atractivos turísticos de Bolivia, usa ubicaciones reales como el Salar de Uyuni cerca de Lat: -20.1, Lon: -67.4 o La Paz en Lat: -16.5, Lon: -68.1).
Cada elemento (Feature) DEBE contener obligatoriamente propiedades (properties) útiles que incluyan un 'nombre', 'categoria', un valor cuantitativo de ejemplo (como 'capacidad', 'poblacion', 'altura_m', 'area_km', etc. según corresponda) y una descripción descriptiva.
Genera de 5 a 8 puntos, líneas o polígonos detallados. Asegura que la estructura de coordenadas geoespaciales sea 100% matemática, sin nulos, flotantes válidos.
Evita truncamientos y devuelve estrictamente el JSON sin comentarios que invaliden el análisis de datos.`;

    const systemInstruction = `Eres un generador automatizado de GeoJSON geográficamente preciso para pruebas en GIS de IDE.
Crea únicamente un JSON bien estructurado que cumpla con los estándares RFC 7946.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: promptText,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            type: { type: Type.STRING },
            name: { type: Type.STRING },
            features: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  type: { type: Type.STRING },
                  properties: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      nombre: { type: Type.STRING },
                      categoria: { type: Type.STRING },
                      valor: { type: Type.NUMBER },
                      descripcion: { type: Type.STRING },
                    },
                    required: ["nombre", "categoria", "valor"],
                  },
                  geometry: {
                    type: Type.OBJECT,
                    properties: {
                      type: { type: Type.STRING },
                      coordinates: {
                        type: Type.ARRAY,
                        items: { type: Type.NUMBER },
                        description: "Coordinates array [longitude, latitude] for Point, or higher nesting for line/polygon."
                      }
                    },
                    required: ["type", "coordinates"],
                  }
                },
                required: ["type", "properties", "geometry"],
              }
            }
          },
          required: ["type", "features"],
        }
      },
    });

    const outputText = response.text || "";
    let parsedGeoJson = null;

    try {
      parsedGeoJson = JSON.parse(outputText);
    } catch (parseError) {
      console.error("Failed to parse Gemini output as GeoJSON directly:", outputText);
      return res.status(500).json({
        success: false,
        error: "La respuesta generada por la IA no tiene un formato GeoJSON estructurado válido.",
      });
    }

    res.json({
      success: true,
      geojson: parsedGeoJson,
    });
  } catch (error: any) {
    console.error("Error creating AI layer:", error);
    res.status(500).json({ success: false, error: error.message || "Error al sintetizar cartografía por IA." });
  }
});

// 3. Mock OGC Services representing IDE catalog endpoints (WMS, WFS)
app.get("/api/ogc/wms", (req, res) => {
  const { request, service } = req.query;

  if (service?.toString().toUpperCase() !== "WMS") {
    return res.status(400).send("WMS service standard is expected.");
  }

  if (request?.toString().toUpperCase() === "GETCAPABILITIES") {
    res.set("Content-Type", "text/xml");
    return res.send(`<?xml version="1.0" encoding="UTF-8"?>
<WMS_Capabilities version="1.3.0" xmlns="http://www.opengis.net/wms">
  <Service>
    <Name>WMS</Name>
    <Title>Servicio de Mapas Web de la IDE GeoSpace</Title>
    <Abstract>Servidor de mapas WMS que distribuye cartografía digital espacial para el visualizador unificado.</Abstract>
    <KeywordList>
      <Keyword>IDE</Keyword>
      <Keyword>GeoSpace</Keyword>
      <Keyword>Visualizador</Keyword>
      <Keyword>Cartografía</Keyword>
    </KeywordList>
    <OnlineResource xmlns:xlink="http://www.w3.org/1999/xlink" xlink:type="simple" xlink:href="${process.env.APP_URL || "http://localhost:3000"}/api/ogc/wms"/>
    <ContactInformation>
      <ContactPersonPrimary>
        <ContactPerson>Especialista GIS</ContactPerson>
        <ContactOrganization>IDE GeoSpace Labs</ContactOrganization>
      </ContactPersonPrimary>
    </ContactInformation>
  </Service>
  <Capability>
    <Request>
      <GetCapabilities>
        <Format>text/xml</Format>
        <DCPType><HTTP><Get><OnlineResource xmlns:xlink="http://www.w3.org/1999/xlink" xlink:type="simple" xlink:href="${process.env.APP_URL || "http://localhost:3000"}/api/ogc/wms"/></Get></OnlineResource></HTTP></DCPType>
      </GetCapabilities>
      <GetMap>
        <Format>image/png</Format>
        <DCPType><HTTP><Get><OnlineResource xmlns:xlink="http://www.w3.org/1999/xlink" xlink:type="simple" xlink:href="${process.env.APP_URL || "http://localhost:3000"}/api/ogc/wms"/></Get></OnlineResource></HTTP></DCPType>
      </GetMap>
    </Request>
    <Exception>
      <Format>XML</Format>
    </Exception>
    <Layer>
      <Title>Capas de IDE GeoSpace</Title>
      <CRS>EPSG:4326</CRS>
      <CRS>EPSG:3857</CRS>
      <Layer queryable="1">
        <Name>capas_base_mundial</Name>
        <Title>Mapas Base Globales del Servidor</Title>
        <Abstract>Fondo de mosaico mundial topográfico</Abstract>
        <EX_GeographicBoundingBox>
          <westBoundLongitude>-180</westBoundLongitude>
          <eastBoundLongitude>180</eastBoundLongitude>
          <southBoundLatitude>-90</southBoundLatitude>
          <northBoundLatitude>90</northBoundLatitude>
        </EX_GeographicBoundingBox>
      </Layer>
    </Layer>
  </Capability>
</WMS_Capabilities>`);
  }

  // Handle standard GetMap request simulation
  if (request?.toString().toUpperCase() === "GETMAP") {
    return res.status(200).json({
      message: "Standard OGC WMS GetMap rendering placeholder. To view layers, interactively drag files on the frontend UI or request AI generated layers."
    });
  }

  res.status(400).send("Unsupported OGC WMS operation request.");
});

app.get("/api/ogc/wfs", (req, res) => {
  const { request, service } = req.query;

  if (service?.toString().toUpperCase() !== "WFS") {
    return res.status(400).send("WFS service standard is expected.");
  }

  if (request?.toString().toUpperCase() === "GETCAPABILITIES") {
    res.set("Content-Type", "text/xml");
    return res.send(`<?xml version="1.0" encoding="UTF-8"?>
<wfs:WFS_Capabilities version="2.0.0" xmlns:wfs="http://www.opengis.net/wfs/2.0">
  <ows:ServiceIdentification xmlns:ows="http://www.opengis.net/ows/1.1">
    <ows:Title>Servicio de Entidades Web de IDE GeoSpace</ows:Title>
    <ows:ServiceType>WFS</ows:ServiceType>
    <ows:ServiceTypeVersion>2.0.0</ows:ServiceTypeVersion>
  </ows:ServiceIdentification>
  <wfs:FeatureTypeList>
    <wfs:FeatureType>
      <wfs:Name>capas_usuario_geojson</wfs:Name>
      <wfs:Title>Entidades Vectoriales Albergadas dinámicamente</wfs:Title>
      <wfs:DefaultCRS>urn:ogc:def:crs:EPSG::4326</wfs:DefaultCRS>
    </wfs:FeatureType>
  </wfs:FeatureTypeList>
</wfs:WFS_Capabilities>`);
  }

  res.status(400).send("Unsupported OGC WFS operation.");
});


// Express dynamic Vite hosting logic
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[IDE GeoSpace Server] Running on http://localhost:${PORT}`);
  });
}

startServer();
